from pathlib import Path
import hashlib
R=Path(__file__).resolve().parent
css=(R/'baseline/style.css').read_text()+'\n'+(R/'src/desk.css').read_text()+'\n'+(R/'src/merged.css').read_text()
js='\n'.join((R/f).read_text() for f in ['baseline/core.js','baseline/spatial.js','src/arrangement.js','src/audio.js','src/inherited-view.js','src/app.js'])
html='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>合拍 / Echoy · 方案 B v4 · 合并式控制条</title><style>'+css+'</style></head><body>'+(R/'src/body.html').read_text()+'<script>'+js+'</script></body></html>'
(R/'index.html').write_text(html);(R.parent/'echoy-arrange-B-v4.html').write_text(html)
print('Built',len(html.encode()),'bytes',hashlib.sha256(html.encode()).hexdigest())
