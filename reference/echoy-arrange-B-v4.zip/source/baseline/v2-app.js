/* Integrates the approved B experience in the existing role-study product pages. */
(function(root){'use strict';
const M=root.RoleAccompaniment,{ROLES,PRESETS,DURATION:D,STEP}=M,{ico,safe}=root.RoleUI;
const keys=['voice','dust','harmony','pulse'],clone=x=>JSON.parse(JSON.stringify(x));
const loopIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9a7 7 0 0 1 12-4l3 3m0-5v5h-5M20 15a7 7 0 0 1-12 4l-3-3m0 5v-5h5"/></svg>';
class ArrangeApp{
 constructor(){this.model=new root.ArrangeModel();this.audio=new root.ArrangeAudio();this.spatial=new root.DuijuSpatial();this.lang='zh-CN';this.selected='A';this.positions={A:{x:32,y:22}};this.proposed=[];this.contactTimer=null;this.network=true;this.token=0;this.data={};this.stagedData={};this.compiling=new Set();this.ui={};this.views={};this.units={};this.previewSequence=0;this.stats=[];
  for(const id of ['A','B','C']){this.ui[id]={route:'home',battery:72,volume:.65,fault:'',loading:false,booting:false,imu:0,left:'none',right:'none',state:'ready',raw:[],captureAt:0,preview:null,loopAt:0,hit:null,lastStep:-1,key:'',localToken:0};this.views[id]=new root.InheritedView(this,id);}
  this.buildDesk();this.bind();this.render();this.timer=setInterval(()=>this.tick(),16);this.frame=this.frame.bind(this);requestAnimationFrame(this.frame);
 }
 t(zh,en){return this.lang==='en'?en:zh;}now(){return this.audio.now();}tile(id){return this.model.tiles[id];}
 blocked(id){const u=this.ui[id];return !this.tile(id).present||u.fault||u.loading||u.booting||u.battery===0;}
 capturing(id){return ['armed','unlocking','recording'].includes(this.ui[id].state);}
 buildDesk(){for(const id of ['A','B','C']){
   const unit=document.createElement('section');unit.className='unit';unit.dataset.tile=id;
   unit.innerHTML=`<div class="device-handle" role="button" tabindex="0" aria-label="Move tile ${id}"><span class="handle-name"></span><span class="handle-grip" aria-hidden="true">⠿</span></div><div class="shell"><div class="screen" data-screen="${id}"></div><i class="hardware ai"></i><i class="hardware boot"></i><i class="hardware power"></i><i class="usb"></i></div>`;
   document.getElementById('stage').appendChild(unit);this.units[id]=unit;this.bindDrag(unit.querySelector('.device-handle'),id,false);
   const chip=document.querySelector(`[data-shelf="${id}"]`);this.bindDrag(chip,id,true);
  }
 }
 selectedId(id){this.selected=id;document.getElementById('sim-target').value=id;this.syncLab();}
 layout(){for(const id of Object.keys(this.units)){const unit=this.units[id],present=this.tile(id).present;unit.hidden=!present;document.querySelector(`[data-shelf="${id}"]`).hidden=present;if(present){unit.style.left=this.positions[id].x+'px';unit.style.top=this.positions[id].y+'px';}}
  document.getElementById('empty-desk').hidden=Object.keys(this.positions).length>0;
 }
 mute(id){const d=this.tile(id),u=this.ui[id];this.model.mute(id);u.localToken++;u.preview=null;if(this.capturing(id)){u.raw=[];u.state='ready';}this.audio.mute(id);this.update(id);}
 stopAll(){for(const id of ['A','B','C'])this.mute(id);this.previewSequence++;this.render();}
 async preview(id,kind='full'){
  const d=this.tile(id),u=this.ui[id];if(this.blocked(id)||this.capturing(id)||!this.data[id]||this.compiling.has(id)||this.model.pending?.changes.includes(id))return;
  this.mute(id);const token=++u.localToken;u.state='preparing';this.update(id);
  try{await this.audio.ensure();if(token!==u.localToken||this.blocked(id))return;this.audio.volumeTile(id,u.volume);const data=this.data[id],now=this.now(),shared=Object.values(this.model.tiles).some(x=>x.id!==id&&x.loop&&x.clockId===d.clockId),origin=this.model.clocks[d.clockId].origin,start=shared?origin+Math.ceil((now+.06-origin)/D)*D:now+.05;
   u.preview={data,start,kind};u.state='ready';this.audio.playTile(id,data,start,false,()=>{if(token===u.localToken){u.preview=null;this.update(id);}},kind);this.update(id);
  }catch(e){if(token===u.localToken)this.fail(id,e);}
 }
 async transport(id){const d=this.tile(id),u=this.ui[id];this.selectedId(id);
  if(d.loop||u.preview||this.capturing(id)||u.state==='preparing'){this.mute(id);return;}
  if(this.blocked(id)||!d.current||this.compiling.has(id)||this.model.pending?.changes.includes(id))return;
  const token=++u.localToken;u.state='preparing';this.update(id);
  try{await this.audio.ensure();if(token!==u.localToken||this.blocked(id))return;this.flush();const at=this.model.enableLoop(id,this.now());if(at===null)return;u.state='ready';u.loopAt=at;u.preview=null;this.audio.volumeTile(id,u.volume);this.audio.playTile(id,this.data[id],at,true);this.update(id);
  }catch(e){if(token===u.localToken)this.fail(id,e);}
 }
 flush(){const pending=this.model.pending;if(!pending||this.now()<pending.at)return;const changed=this.model.commit(this.now());for(const row of changed){this.data[row.id]=this.stagedData[row.id];this.audio.finalize(row.id);this.ui[row.id].key='';if(!row.plan)this.mute(row.id);}
  const auto=this.autoAfterCommit;this.autoAfterCommit=null;this.compiling.clear();this.render();if(auto&&this.tile(auto).present&&this.tile(auto).current&&!this.tile(auto).loop)this.preview(auto);
 }
 async refresh(auto=null){
  this.audio.cancelAll();const ticket=++this.token,job=this.model.compile();this.model.pending=null;this.autoAfterCommit=null;
  this.compiling=new Set(Object.keys(job.plans).filter(id=>job.plans[id]?.signature!==this.tile(id).current?.signature||job.clocks[id]&&job.clocks[id]!==this.tile(id).clockId));this.render();
  try{const entries=await Promise.all(Object.entries(job.plans).map(async([id,p])=>[id,p?await this.audio.preparePlan(p):null]));if(ticket!==this.token)return;
   const staged=this.model.stage(job,this.now());if(!staged)return;this.stagedData=Object.fromEntries(entries);this.compiling.clear();
   const latestOnce=Math.max(0,...staged.changes.map(id=>this.ui[id].preview?this.ui[id].preview.start+D:0));staged.at=Math.max(staged.at,latestOnce);
   this.autoAfterCommit=auto;
   for(const id of staged.changes)if(this.tile(id).loop&&this.stagedData[id]&&!this.blocked(id))this.audio.queueTile(id,this.stagedData[id],staged.at);
   this.render();
  }catch(e){if(ticket!==this.token)return;this.model.pending=null;this.compiling.clear();this.autoAfterCommit=null;this.ui[this.selected].message=this.t('新声音没有准备好，原来的继续','Preparation failed; current sound continues');this.stats.push({type:'prepare-failed',error:String(e)});this.render();}
 }
 change(id,patch){if(this.blocked(id)||this.capturing(id))return;if(this.ui[id].preview&&this.now()<this.ui[id].preview.start)this.mute(id);this.flush();this.selectedId(id);this.model.configure(id,patch);this.refresh();}
 async tap(id){const d=this.tile(id),u=this.ui[id];if(this.blocked(id)||u.route!=='home')return;this.selectedId(id);
  const canRecord=!d.current?.source&&!d.loop&&!u.preview;
  if(u.state==='recording'){const dt=this.now()-u.captureAt;if(dt<D){u.raw.push(dt);this.audio.tapTile(id);u.hit=this.now();}return;}
  if(u.state==='unlocking'){u.stamps.push(performance.now()/1000);return;}
  if(!canRecord&&u.state!=='armed'){try{await this.audio.ensure();if(!this.blocked(id)){this.audio.volumeTile(id,u.volume);this.audio.tapTile(id);u.hit=this.now();}}catch(e){this.fail(id,e);}return;}
  this.mute(id);u.state='unlocking';u.stamps=[performance.now()/1000];const token=++u.localToken;this.update(id);
  try{await this.audio.ensure();if(token!==u.localToken||this.blocked(id))return;const last=u.stamps.at(-1),first=u.stamps[0];u.captureAt=this.now()-(last-first);u.raw=u.stamps.map(t=>t-first);u.stamps=[];u.state='recording';this.audio.volumeTile(id,u.volume);this.audio.tapTile(id);u.hit=this.now();this.update(id);}catch(e){if(token===u.localToken)this.fail(id,e);}
 }
 arm(id){if(this.blocked(id)||this.tile(id).current?.source)return;this.mute(id);this.ui[id].state='armed';this.ui[id].route='home';this.render();}
 async example(id='A'){if(this.blocked(id)||this.capturing(id))return;this.mute(id);try{await this.audio.ensure();if(this.blocked(id))return;this.flush();this.model.setSeed(id,root.PulseLab.clean(PRESETS.close.map(step=>({step,kind:'kick',vel:.74}))));this.refresh(id);}catch(e){this.fail(id,e);}}
 confirmGeometry(){clearTimeout(this.contactTimer);this.proposed=this.network?this.spatial.edges(this.positions).map(e=>({left:e.left,right:e.right})):[];this.paintSeams();
  this.contactTimer=setTimeout(()=>{this.contactTimer=null;this.flush();this.model.setEdges(this.proposed);this.refresh();},450);
 }
 add(id,p){if(this.tile(id).present)return;this.positions[id]=p||this.freePosition();this.model.present(id,true);this.ui[id].booting=true;this.ui[id].route='home';this.layout();this.render();setTimeout(()=>{this.ui[id].booting=false;this.confirmGeometry();this.render();},220);}
 freePosition(){let p={x:32,y:22};while(this.spatial.collision('_new',p,this.positions)){p.x+=560;if(p.x>1400){p.x=32;p.y+=588;}}return p;}
 remove(id){this.flush();this.mute(id);delete this.positions[id];this.model.present(id,false);this.ui[id].route='home';this.layout();this.confirmGeometry();}
 fail(id,e){this.mute(id);this.ui[id].fault=String(e?.message||e);this.ui[id].key='';this.render();}
 recover(id){this.mute(id);const u=this.ui[id];u.fault='';u.loading=false;u.battery=u.battery||72;u.route='home';u.key='';this.render();}
 tick(){this.flush();for(const id of ['A','B','C']){const u=this.ui[id];if(u.state==='recording'&&this.now()-u.captureAt>=D){const seed=M.quantize(u.raw);u.lastRaw=u.raw.slice();u.raw=[];u.state='ready';if(seed.length){this.model.setSeed(id,seed);this.refresh(id);}}
  this.update(id);
 }this.paintSeams();}
 render(){this.layout();for(const id of ['A','B','C'])this.renderTile(id);this.paintOutside();this.paintSeams();}
 html(id,text){return text.replace(/\bid="([^"]+)"/g,'data-slot="$1"');}
 renderTile(id){const d=this.tile(id),u=this.ui[id],screen=this.units[id].querySelector('.screen'),view=this.views[id];if(!d.present)return;
  const actual=d.current?[d.current.role,d.current.phrase]:[d.role,d.phrase];const k=JSON.stringify([this.lang,u.route,d.role,d.phrase,u.battery,this.blocked(id),u.booting,actual]);screen.style.setProperty('--accent',ROLES[actual[0]].color);
  if(k!==u.key){u.key=k;let html;if(this.blocked(id))html=this.problem(id);else if(u.route==='home'){view.actual=true;html=view.home();view.actual=false;}else if(u.route==='role'){screen.style.setProperty('--accent',ROLES[d.role].color);html=view.rolePage();}else if(u.route==='settings')html=this.settings(id);else html=this.detail(id);screen.innerHTML=this.html(id,html)+'<div class="seam-mark left" aria-hidden="true"></div><div class="seam-mark right" aria-hidden="true"></div>';this.bindHome(id);this.drawGallery(id);}
  this.update(id);if(u.route==='role')this.drawGallery(id);this.units[id].querySelector('.handle-name').textContent=this.t('拖动外壳 · ','Drag case · ')+id;
 }
 settings(id){const v=this.views[id],d=this.tile(id);return `<section class="page" data-route="settings">${v.header(this.t('设置','Settings'))}<div class="scroll-list"><button class="row" data-act="audition">${ico('play')}<span>${this.t('先听一次','Hear once')}</span></button><button class="row" data-act="record" ${d.current?.source?'disabled':''}>${ico('record')}<span>${this.t(d.current?.source?'先拆开左侧，再录自己的节奏':'重新敲一段',d.current?.source?'Unlink left to record your rhythm':'Record your rhythm again')}</span></button><button class="row" data-act="guide">${ico('help')}<span>${this.t('怎么玩','How to play')}</span>${ico('next')}</button><button class="row" data-act="info">${ico('wave')}<span>${this.t('设备与实验说明','Device & experiment')}</span>${ico('next')}</button><button class="row" data-act="export">${ico('download')}<span>${this.t('导出本次节奏','Export this session')}</span></button><div class="row lang-row"><span>${this.t('语言','Language')}</span><button class="lang-small" data-lang="zh-CN">中文</button><button class="lang-small" data-lang="en">EN</button></div><button class="row" data-act="remove">${ico('cross')}<span>${this.t('收起这台（模拟）','Put away this tile')}</span></button></div></section>`;}
 detail(id){const u=this.ui[id],d=this.tile(id),v=this.views[id];const guide=u.route==='guide';let html;
  if(guide)html=`<h3>${this.t('先听一次，喜欢再循环。','Hear once. Then make it loop.')}</h3><p>${this.t('独立的一台：敲中央，第一下开始记四拍，随后附和一次就停。点首页的「循环」，才会持续演奏；再点只静音本机。','On a solo tile, the first tap starts four beats of recording, then one reply. Press Loop for steady playback. Press again to mute only this tile.')}</p><h3>${this.t('把另一台放到右边。','Place another tile on its right.')}</h3><p>${this.t('拖外壳贴近，等接缝确认。新设备先保持静音；点它自己的「循环」加入。换位置，改变左到右的回应；拆开不清空，也不强制停止。','Drag the cases to snap, then wait for confirmation. A new tile stays silent until you press its Loop. Reorder to change who follows whom. Splitting keeps the rhythm and does not force a stop.')}</p><p>${this.t('循环中的普通敲击只是试奏，不覆盖已有音乐。角色、表达与丰富程度在拍点切入，音量立即生效。重新录入在设置里。','Taps during a loop only audition; they never overwrite it. Voice, phrase and richness changes wait for a bar boundary. Volume responds immediately. Re-record in Settings.')}</p>`;
  else html=`<h3>${this.t('单机与多机，同一套声音。','Same instrument, solo or together.')}</h3><p>${this.t('480×480 内屏，R60圆角。四个角色各三种表达来自上一版；原始节奏保留。多机使用左侧完整乐句的主次与音高信息组织自己的附和，不复制全部装饰音。','480×480 display, R60 corners. Twelve expressions retain the previous solo engine. Neighbors use the left phrase’s hierarchy and supplied pitches rather than multiplying all decorative events.')}</p><p>${this.t('本机','Tile')} ${id} · ${u.battery}% · IMU ${u.imu}°<br>${this.t('左 / 右扩展','Left / right slot')}: ${safe(u.left)} / ${safe(u.right)}<br>${this.t('来自左侧','Following')}: ${d.current?.source||'—'}</p><small>${this.t('只是浏览器仿真，共享电脑音频时钟；未验证真机无线、声学同步或GPIO。声音比较的数值匹配不代表主观等响。数据只保留在当前页面内存。','Browser simulation shares the computer audio clock. No hardware wireless, acoustic sync or GPIO verification. RMS matching is not certified perceived loudness. Data lives in this page’s memory only.')}</small>`;
  return `<section class="page" data-route="detail">${v.header(this.t(guide?'怎么玩':'设备与实验说明',guide?'How to play':'Device & experiment'))}<div class="detail">${html}</div></section>`;
 }
 problem(id){const u=this.ui[id],v=this.views[id];const title=u.fault?this.t('暂时无法发声','Audio unavailable'):u.battery===0?this.t('电量已耗尽','Battery empty'):this.t('准备声音','Preparing sound');return `<section class="page status-page" data-route="status"><div class="status-art ${!u.fault?'loading':''}">${ico('wave')}</div><h2>${title}</h2><p>${this.t('节奏保留，恢复不会自动发声。','Rhythm is kept. Recovery never autoplays.')}</p><button data-act="recover">${this.t('恢复到静止','Restore, stay silent')}</button></section>`;}
 update(id){const d=this.tile(id),u=this.ui[id],screen=this.units[id]?.querySelector('.screen');if(!screen||!d.present||this.blocked(id))return;
  const pending=this.model.pending?.changes.includes(id),preparing=this.compiling.has(id),capture=this.capturing(id),busy=!!(u.preview||d.loop||capture||u.state==='preparing');
  const put=(slot,text)=>{const el=screen.querySelector(`[data-slot="${slot}"]`);if(el&&el.textContent!==text)el.textContent=text;};
  let status,hint;
  if(capture){status=this.t(u.state==='recording'?'正在记你的节奏':'等第一下敲击',u.state==='recording'?'Capturing your rhythm':'Waiting for your first tap');hint=this.t('记四拍 · 随后只附和一次','Four beats, then one reply');}
  else if(preparing){status=this.t('准备新的声音','Preparing a new sound');hint=this.t('原来的继续，可随时静音本机','Current sound continues; local mute always works');}
  else if(pending){status=this.t('下一小节生效','Changes at the next bar');hint=this.t('已经收到，不会中途重编','Received · Current phrase stays intact');}
  else if(u.preview){status=this.now()<u.preview.start?this.t('等共同拍点试听','Audition at the shared beat'):this.t('先听这一次','Hear this one reply');hint=this.t('结束就停 · 喜欢再循环','Stops after one reply · Loop when you like it');}
  else if(d.loop){status=d.current?.source?this.t('回应左侧','Following left'):this.t('稳定循环','Steady loop');hint=this.now()<u.loopAt?this.t('等共同拍点开始','Waiting for the shared beat'):this.t('换个表达，或把声音摆在一起','Try a phrase, or bring another voice alongside');}
  else if(d.current){status=d.current.source?this.t('已接住左侧的节奏','Left rhythm received'):this.t('这段留在这里了','Your rhythm is here');hint=this.t('点「循环」持续演奏 · 只控制本机','Loop to keep playing · This tile only');}
  else{status=this.t('敲几下，先听一次','Tap a few times. Hear one reply.');hint=this.t('不需要选音高 · 第一敲开始','No pitch choices · Start with one tap');}
  put('state',status);put('hint',u.message||hint);put('touch-label',!d.current&&!capture?this.t('在这里敲几下','Tap here'):'');
  screen.querySelector('.pad')?.classList.toggle('empty',!d.current&&!capture);
  for(const el of screen.querySelectorAll('[data-control]')){const v=el.dataset.control==='volume'?u.volume:d.density;el.style.setProperty('--value',v);el.setAttribute('aria-valuenow',Math.round(v*100));}
  const transport=screen.querySelector('[data-slot="transport"]');if(transport){const tag=busy?'stop':'loop';if(transport.dataset.mode!==tag||transport.dataset.renderLocale!==this.lang){transport.dataset.mode=tag;transport.dataset.renderLocale=this.lang;transport.innerHTML=(busy?ico('stop'):loopIcon)+`<span class="transport-label">${this.t(busy?'静音':'循环',busy?'Mute':'Loop')}</span>`;}transport.setAttribute('aria-label',this.t(busy?'停止本机声音':'循环这段，只控制本机',busy?'Stop this tile':'Loop this tile'));transport.classList.toggle('active',d.loop);transport.disabled=!busy&&(!d.current||pending||preparing);}
  const gallery=screen.querySelector('[data-slot="gallery-play"]');if(gallery){const mode=busy?'stop':'audition';if(gallery.dataset.mode!==mode||gallery.dataset.renderLocale!==this.lang){gallery.innerHTML=(busy?ico('stop'):ico('play'))+`<span>${this.t(busy?'静音本机':'试听一次',busy?'Mute this tile':'Hear once')}</span>`;gallery.dataset.mode=mode;gallery.dataset.renderLocale=this.lang;}gallery.disabled=!busy&&(!d.current||pending||preparing);}
  for(const btn of screen.querySelectorAll('[data-phrase],[data-act="prev-role"],[data-act="next-role"],[data-act="role"],[data-act="settings"]'))btn.disabled=capture;
 }
 drawGallery(id){const d=this.tile(id),u=this.ui[id];if(u.route!=='role')return;for(const c of this.units[id].querySelectorAll('[data-role-art]')){const role=c.dataset.roleArt;const raw=d.current?.rootSeed||d.ownSeed,notes=raw.length?M.compose(raw,role,role===d.role?d.phrase:d.memories[role],d.density).full:[];root.RoleArt.draw(c,role,notes);}}
 paintSeams(){for(const id of ['A','B','C']){const screen=this.units[id].querySelector('.screen');for(const side of ['left','right']){const el=screen.querySelector('.seam-mark.'+side);if(!el)continue;const find=edges=>edges.find(e=>e[side==='left'?'right':'left']===id);const established=find(this.model.edges),wanted=find(this.proposed),same=established&&wanted&&established.left===wanted.left&&established.right===wanted.right;el.className='seam-mark '+side+(same?' connected':established||wanted?' pending':'');}}}
 paintOutside(){const put=(id,text)=>{const el=document.getElementById(id);if(el&&el.textContent!==text)el.textContent=text;};
  put('page-title',this.t('先敲一段，再把声音摆在一起。','Tap a rhythm. Bring the voices together.'));
  put('page-desc',this.t('先听一次附和；喜欢就点本机「循环」。拖入另一台，靠右吸合，再开启它自己的循环。','Hear one reply. Press Loop to keep it. Drag another tile beside it, then enable that tile’s own loop.'));
  put('sample',this.t('先听“两下紧挨”的示例','Try a close-pair example'));
  document.getElementById('sample').disabled=this.blocked('A')||this.capturing('A')||!!this.tile('A').current?.source;
  put('desk-help',this.t('拖上方外壳移动 · 拆开不清空、不强制暂停 · 每台单独发声','Drag the top case handles · Splitting keeps sound and rhythm · Each tile controls its own output'));
  put('shelf-title',this.t('再拿一台 · 拖到桌上','Another voice · Drag onto the desk'));
  for(const id of ['A','B','C']){const d=this.tile(id),chip=document.querySelector(`[data-shelf="${id}"]`);chip.querySelector('strong').textContent=this.views[id].name(d.role);chip.querySelector('span').textContent=this.t('拖上桌 · 初始静音','Drag onto desk · Starts silent');}
  put('empty-desk',this.t('把下面的一台拖上来，开始演奏。','Drag a tile from below to start.'));
  put('lab-summary',this.t('模拟与检查（不必先看）','Simulation & checks (optional)'));
  put('footer-note',this.t('方案 B 整合实验 · 不覆盖 v5.1.0 · 共享浏览器音频时钟，不是真机同步','Scheme B study · v5.1.0 untouched · Shared browser clock, not hardware sync'));
 }
 bindHome(id){const screen=this.units[id].querySelector('.screen'),pad=screen.querySelector('.pad');if(pad){pad.onpointerdown=e=>{if(e.button!==0||e.isPrimary===false)return;e.preventDefault();pad.focus({preventScroll:true});this.tap(id);};pad.onkeydown=e=>{if(['Enter',' '].includes(e.key)&&!e.repeat){e.preventDefault();this.tap(id);}};}
  for(const el of screen.querySelectorAll('[data-control]')){let drag=null;const volume=el.dataset.control==='volume';const get=()=>volume?this.ui[id].volume:this.tile(id).density;const set=v=>{v=Math.min(1,Math.max(0,v));if(volume){this.ui[id].volume=v;this.audio.volumeTile(id,v);this.update(id);}else{if(this.ui[id].preview&&this.now()<this.ui[id].preview.start)this.mute(id);this.flush();this.model.configure(id,{density:v});this.audio.cancelAll();this.token++;this.compiling.add(id);clearTimeout(this.densityTimer);this.densityTimer=setTimeout(()=>this.refresh(),85);this.update(id);}};
   el.onpointerdown=e=>{if(e.button!==0||e.isPrimary===false)return;e.preventDefault();this.selectedId(id);el.setPointerCapture(e.pointerId);drag={id:e.pointerId,y:e.clientY,v:get()};el.classList.add('grabbing');};el.onpointermove=e=>{if(drag?.id===e.pointerId)set(drag.v+(drag.y-e.clientY)/180);};const end=e=>{if(drag?.id===e.pointerId){drag=null;el.classList.remove('grabbing');if(!volume){clearTimeout(this.densityTimer);this.refresh();}}};el.onpointerup=end;el.onpointercancel=end;el.onlostpointercapture=end;el.onkeydown=e=>{if(['ArrowUp','ArrowDown','Home','End'].includes(e.key)){e.preventDefault();set(e.key==='Home'?0:e.key==='End'?1:get()+(e.key==='ArrowUp'?.05:-.05));}};
  }
 }
 bind(){document.body.addEventListener('click',e=>{const b=e.target.closest('button');if(!b||b.disabled)return;if(b.dataset.lang){this.lang=b.dataset.lang;document.documentElement.lang=this.lang;this.render();return;}
  const id=b.closest('[data-tile]')?.dataset.tile;if(!id)return;this.selectedId(id);const d=this.tile(id),u=this.ui[id];if(b.dataset.phrase){this.change(id,{phrase:+b.dataset.phrase});return;}
  const act=b.dataset.act;if(act==='play'){if(u.route==='role'){if(d.loop||u.preview)this.mute(id);else this.preview(id);}else this.transport(id);}else if(act==='prev-role'||act==='next-role')this.change(id,{role:keys[(keys.indexOf(d.role)+(act==='next-role'?1:3))%4]});else if(['role','settings','guide','info'].includes(act)){u.route=act;this.renderTile(id);}else if(act==='back'){u.route=['info','guide'].includes(u.route)?'settings':'home';this.renderTile(id);}else if(act==='record')this.arm(id);else if(act==='audition'){u.route='home';this.renderTile(id);this.preview(id);}else if(act==='remove')this.remove(id);else if(act==='recover')this.recover(id);else if(act==='export')this.export();});
  document.getElementById('sample').onclick=()=>this.example('A');document.getElementById('sim-target').onchange=e=>this.selectedId(e.target.value);
  document.getElementById('sim-battery').oninput=e=>{const id=this.selected;this.ui[id].battery=+e.target.value;if(!+e.target.value)this.mute(id);this.renderTile(id);};
  document.getElementById('sim-imu').oninput=e=>{this.ui[this.selected].imu=+e.target.value;this.ui[this.selected].key='';this.renderTile(this.selected);};
  for(const side of ['left','right'])document.getElementById('sim-'+side).onchange=e=>{this.ui[this.selected][side]=e.target.value;this.ui[this.selected].key='';this.renderTile(this.selected);};
  document.getElementById('sim-network').onchange=e=>{this.network=e.target.value==='online';this.confirmGeometry();};
  document.getElementById('sim-fault').onclick=()=>this.fail(this.selected,new Error('Simulated output failure'));
  document.getElementById('sim-loading').onclick=()=>{this.mute(this.selected);this.ui[this.selected].loading=true;this.renderTile(this.selected);};
  document.getElementById('sim-recover').onclick=()=>this.recover(this.selected);document.getElementById('sim-remove').onclick=()=>this.remove(this.selected);
  document.getElementById('export-all').onclick=()=>this.export();
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){this.stopAll();}else if(e.code==='Space'&&!e.repeat&&!e.target.closest('button,input,select,[role]')){e.preventDefault();this.transport(this.selected);}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)this.stopAll();});root.addEventListener('pagehide',()=>this.stopAll());
 }
 syncLab(){const u=this.ui[this.selected];document.getElementById('sim-battery').value=u.battery;document.getElementById('sim-imu').value=u.imu;for(const s of ['left','right'])document.getElementById('sim-'+s).value=u[s];}
 export(){const payload={study:'Echoy Arrange B 06',simulated:true,edges:this.model.edges,positions:this.positions,tiles:Object.fromEntries(Object.entries(this.model.tiles).map(([id,d])=>[id,{role:d.role,phrase:d.phrase,density:d.density,ownSeed:d.ownSeed,current:d.current,loop:d.loop,clock:d.clockId}])),limitations:['browser shared clock, not wireless sync','16-step rhythm quantization','neighbor adapter newly tested; single-tile source engine retained']};const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));a.href=url;a.download='echoy-arrange-B-session.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 frame(){for(const id of ['A','B','C']){if(!this.tile(id).present||this.ui[id].route!=='home'||this.blocked(id))continue;const d=this.tile(id),u=this.ui[id],s=this.units[id].querySelector('.screen'),c=s.querySelector('.pad canvas');if(!c)continue;const now=this.now(),recording=u.state==='recording',once=u.preview,plan=d.current;const progress=recording?(now-u.captureAt)/D:once?(now-once.start)/D:this.model.phase(id,now);const active=recording||!!once&&progress>=0&&progress<1||d.loop&&now>=u.loopAt;
   const notes=recording?M.compose(M.quantize(u.raw),d.role,d.phrase,d.density).foreground:once?once.data.arrays&&once.kind==='source'?once.data.plan.rootSeed:once.kind==='foreground'?once.data.plan.foreground:once.data.plan.full:plan?.full||[];
   const role=recording?d.role:once?.kind==='source'?'pulse':once?once.data.plan.role:plan?.role||d.role,step=Math.min(15,Math.floor(Math.max(0,progress)*16));
   if(active&&step!==u.lastStep){if(notes.some(n=>Math.floor(n.step)===step))u.hit=now;u.lastStep=step;}
   root.RoleArt.draw(c,role,notes,Math.max(0,Math.min(1,progress)),active,u.hit?Math.max(0,1-(now-u.hit)/.4):0);
   for(const dot of s.querySelectorAll('[data-step]')){const matches=notes.filter(n=>Math.floor(n.step)===+dot.dataset.step);dot.className=matches.length?'hit '+(matches.some(n=>n.layer==='anchor'||n.role==='anchor'||(!n.layer&&!n.role))?'anchor':'support'):'';if(active&&step===+dot.dataset.step)dot.classList.add('current');}
   const line=s.querySelector('.progress-line');line.classList.toggle('shown',recording||!!once);line.querySelector('i').style.width=Math.max(0,Math.min(1,progress))*100+'%';
  }
  if(document.getElementById('lab').open&&(!this.auditAt||performance.now()-this.auditAt>400)){this.auditAt=performance.now();document.getElementById('audit').textContent=JSON.stringify({edges:this.model.edges,pending:this.model.pending?{at:this.model.pending.at,changes:this.model.pending.changes}:null,tiles:Object.fromEntries(Object.entries(this.model.tiles).map(([id,d])=>[id,{source:d.current?.source||null,role:d.current?.role||d.role,phrase:d.current?.phrase||d.phrase,loop:d.loop,clock:d.clockId,onsets:d.current?.full.length||0}]))},null,2);}
  requestAnimationFrame(this.frame);
 }
 bindDrag(el,id,reserve){let drag=null;
  el.addEventListener('pointerdown',e=>{if(e.button!==0||e.isPrimary===false)return;e.preventDefault();el.setPointerCapture(e.pointerId);this.selectedId(id);const stage=document.getElementById('stage').getBoundingClientRect(),p=this.positions[id];drag={id:e.pointerId,x:e.clientX,y:e.clientY,offsetX:reserve?254:e.clientX-stage.x-p.x,offsetY:reserve?20:e.clientY-stage.y-p.y,old:p?{...p}:null,moved:false};if(!reserve)this.units[id].classList.add('moving');});
  el.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;if(Math.abs(e.clientX-drag.x)+Math.abs(e.clientY-drag.y)>5)drag.moved=true;if(!drag.moved)return;
   const viewport=document.getElementById('viewport'),v=viewport.getBoundingClientRect();if(e.clientX>v.right-38)viewport.scrollLeft+=25;if(e.clientX<v.left+38)viewport.scrollLeft-=25;if(e.clientY>v.bottom-30)viewport.scrollTop+=18;if(e.clientY<v.top+30)viewport.scrollTop-=18;
   const stage=document.getElementById('stage').getBoundingClientRect();drag.point={x:Math.max(12,Math.min(1850-508,e.clientX-stage.x-drag.offsetX)),y:Math.max(12,Math.min(1160-566,e.clientY-stage.y-drag.offsetY))};
   const snap=this.spatial.snap(id,drag.point,this.positions);drag.snap=snap;
   const ghost=document.getElementById('snap-ghost');ghost.hidden=!snap.snapped;ghost.style.left=snap.x+'px';ghost.style.top=snap.y+'px';
   if(!reserve){this.units[id].style.left=drag.point.x+'px';this.units[id].style.top=drag.point.y+'px';}
  });
  const end=(e,cancel)=>{if(!drag||drag.id!==e.pointerId)return;document.getElementById('snap-ghost').hidden=true;this.units[id].classList.remove('moving');if(!cancel&&drag.moved&&drag.point){const vp=document.getElementById('viewport').getBoundingClientRect(),inside=e.clientX>=vp.x&&e.clientX<=vp.right&&e.clientY>=vp.y&&e.clientY<=vp.bottom;const p=drag.snap?.snapped?{x:drag.snap.x,y:drag.snap.y}:drag.point;
    if(inside&&!this.spatial.collision(id,p,this.positions)){if(reserve)this.add(id,p);else{this.positions[id]=p;this.confirmGeometry();}}
    else if(!reserve){const dock=document.getElementById('shelf').getBoundingClientRect();if(e.clientY>=dock.y&&e.clientY<=dock.bottom)this.remove(id);}
   }drag=null;this.layout();};
  el.addEventListener('pointerup',e=>end(e,false));el.addEventListener('pointercancel',e=>end(e,true));el.addEventListener('lostpointercapture',e=>{if(drag)end(e,true);});
  el.addEventListener('keydown',e=>{if(reserve&&['Enter',' '].includes(e.key)){e.preventDefault();this.add(id);return;}const deltas={ArrowLeft:[-32,0],ArrowRight:[32,0],ArrowUp:[0,-32],ArrowDown:[0,32]};if(reserve||!deltas[e.key])return;e.preventDefault();const [dx,dy]=deltas[e.key],old=this.positions[id],p={x:Math.max(12,old.x+dx),y:Math.max(12,old.y+dy)},snap=this.spatial.snap(id,p,this.positions);if(!snap.collision){this.positions[id]={x:snap.x,y:snap.y};this.layout();this.confirmGeometry();}});
 }
}
root.arrange=new ArrangeApp();root.ArrangeApp=ArrangeApp;
})(window);
