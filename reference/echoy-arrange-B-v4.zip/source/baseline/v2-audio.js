/* Pre-rendered loops retain RoleAudio/DuijuSynth. Per-device gains and cancellable
   boundary handovers replace the old one-device playback adapter only. */
(function(root){'use strict';
const D=root.RoleAccompaniment.DURATION,SR=24000;
class ArrangeAudio extends root.RoleAudio{
 constructor(){super();this.volume=.45;this.mix={};this.linkCache=new Map();this.switches=[];this.offset=null;}
 async ensure(){await super.ensure();if(this.offset===null)this.offset=performance.now()/1000-this.ctx.currentTime;}
 now(){return this.ctx&&this.offset!==null?this.ctx.currentTime+this.offset:performance.now()/1000;}
 time(at){return Math.max(this.ctx.currentTime,at-this.offset);}
 channel(id){if(!this.mix[id]){const gain=this.ctx.createGain();gain.gain.value=.65;gain.connect(this.master);const live=new root.DuijuSynth(this.ctx,gain);live.setVolume(.55);this.mix[id]={gain,live,current:null,queued:null};}return this.mix[id];}
 volumeTile(id,value){if(this.ctx)this.channel(id).gain.gain.setTargetAtTime(value,this.ctx.currentTime,.015);}
 tapTile(id){const c=this.channel(id);c.live.note('finger',{kind:'kick',vel:.78,dur:.22,note:38,expression:0},this.ctx.currentTime+.003,0);}
 async preparePlan(plan){
  if(!plan)return null;const key=plan.signature;if(this.linkCache.has(key))return this.linkCache.get(key);
  let data;
  if(!plan.source&&!plan.detached){data=await super.prepareRole(plan.rootSeed,plan.role,plan.phrase,plan.density);data={...data,key,plan};}
  else{
   const [main,full,raw]=await Promise.all([this.renderRoleNotes(plan.foreground,plan.role),this.renderRoleNotes(plan.full,plan.role),this.renderNotes(plan.rootSeed)]);
   const matched=root.ReplyAB.normalise({sparse:main,layered:full}),rs=root.ReplyAB.stats(raw),gain=rs.rms?Math.min(.65/rs.peak,matched.metrics.targetRms/rs.rms):0;
   data={key,plan,arrays:{full:matched.layered,foreground:matched.sparse,source:Float32Array.from(raw,x=>x*gain)},duration:D,sampleRate:SR,metrics:matched.metrics};
  }
  this.linkCache.set(key,data);if(this.linkCache.size>90)this.linkCache.delete(this.linkCache.keys().next().value);return data;
 }
 make(id,data,at,loop,kind='full',done=()=>{}){
  const c=this.channel(id),buffer=this.ctx.createBuffer(1,data.arrays[kind].length,SR);buffer.copyToChannel(data.arrays[kind],0);
  const source=this.ctx.createBufferSource(),gate=this.ctx.createGain();source.buffer=buffer;source.loop=loop;source.loopStart=0;source.loopEnd=D;source.connect(gate);gate.connect(c.gain);
  const start=this.time(at);gate.gain.setValueAtTime(1,start);source.start(start);const record={source,gate,at:start+this.offset,data,loop,kind,id};
  source.onended=()=>{try{source.disconnect();gate.disconnect();}catch(_){}if(c.current===record){c.current=null;done();}this.audit.push({type:'ended',id,at:this.now()});};
  this.audit.push({type:loop?'loop-start':'once-start',id,at:record.at,key:data.key});return record;
 }
 dispose(record,at=this.now()){if(!record)return;const t=this.time(at);record.gate.gain.cancelScheduledValues(t);record.gate.gain.setValueAtTime(1,t);record.gate.gain.linearRampToValueAtTime(0,t+.008);try{record.source.stop(t+.010);}catch(_){} }
 playTile(id,data,at,loop,done,kind='full'){this.mute(id);const c=this.channel(id);c.current=this.make(id,data,at,loop,kind,done);return c.current.at;}
 queueTile(id,data,at){const c=this.channel(id);this.cancelTile(id);if(!c.current)return;
  const next=this.make(id,data,at,true),old=c.current,t=this.time(at);next.gate.gain.setValueAtTime(0,t);next.gate.gain.linearRampToValueAtTime(1,t+.008);
  old.gate.gain.cancelScheduledValues(t);old.gate.gain.setValueAtTime(1,t);old.gate.gain.linearRampToValueAtTime(0,t+.008);c.queued={next,old,at};
 }
 cancelTile(id){const c=this.mix[id];if(!c?.queued)return;const q=c.queued;c.queued=null;
  if(this.now()<q.at){q.next.gate.gain.cancelScheduledValues(this.ctx.currentTime);q.next.gate.gain.setValueAtTime(0,this.ctx.currentTime);try{q.next.source.stop(this.ctx.currentTime);}catch(_){}q.old.gate.gain.cancelScheduledValues(this.ctx.currentTime);q.old.gate.gain.setValueAtTime(1,this.ctx.currentTime);}
  else{c.current=q.next;this.dispose(q.old);}
 }
 finalize(id){const c=this.mix[id];if(!c?.queued)return;const q=c.queued;c.queued=null;c.current=q.next;try{q.old.source.stop(this.ctx.currentTime+.011);}catch(_){}this.audit.push({type:'commit',id,at:q.at});}
 cancelAll(){for(const id of Object.keys(this.mix))this.cancelTile(id);}
 mute(id){const c=this.mix[id];if(!c)return;this.cancelTile(id);const old=c.current;c.current=null;this.dispose(old);c.live.stop();this.audit.push({type:'mute',id,at:this.now()});}
 shutdown(){for(const id of Object.keys(this.mix))this.mute(id);}
}
root.ArrangeAudio=ArrangeAudio;
})(window);
