(function(root){
class DuijuSpatial{
 constructor(){this.width=508;this.height=566;this.gap=8;this.threshold=44;}
 collision(id,p,positions){return Object.entries(positions).some(([other,q])=>other!==id&&p.x<q.x+this.width-2&&p.x+this.width-2>q.x&&p.y<q.y+this.height-20&&p.y+this.height-20>q.y);}
 snap(id,p,positions){
  const candidates=[];
  for(const [other,q]of Object.entries(positions)){if(other===id)continue;for(const sign of [-1,1]){const target={x:q.x+sign*(this.width+this.gap),y:q.y};const dx=p.x-target.x,dy=p.y-target.y;if(Math.abs(dx)<=this.threshold&&Math.abs(dy)<=this.threshold&&target.x>=12&&target.y>=12&&!this.collision(id,target,positions))candidates.push({...target,score:dx*dx+dy*dy,other});}}
  candidates.sort((a,b)=>a.score-b.score);if(candidates.length)return{...candidates[0],snapped:true,collision:false};
  return{...p,snapped:false,collision:this.collision(id,p,positions)};
 }
 edges(positions){const edges=[];for(const [left,a]of Object.entries(positions))for(const [right,b]of Object.entries(positions))if(left!==right&&Math.abs((b.x-a.x)-(this.width+this.gap))<=3&&Math.abs(a.y-b.y)<=6)edges.push({left,right,state:'connected'});return edges;}
}
root.DuijuSpatial=DuijuSpatial;
})(typeof window!=='undefined'?window:globalThis);
