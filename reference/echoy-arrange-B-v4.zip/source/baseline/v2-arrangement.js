/* Scheme B: same accepted single-tile generator; explicit local loop permission.
   This adapter uses structured upstream plans, never their rendered PCM as input.
   Musical clocks are logical browser clocks, NOT a wireless synchronization test. */
(function(root){'use strict';
const M=root.RoleAccompaniment,P=root.PulseLab,D=M.DURATION,clone=x=>JSON.parse(JSON.stringify(x));
const cfg=p=>[p.role,p.phrase,p.density],same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const anchor=n=>n.layer==='anchor'||n.role==='anchor',support=n=>!anchor(n);
const pitched=n=>Array.isArray(n.notes)?n.notes.at(-1):n.kind==='tone'||n.kind==='grain'?n.note:null;
const scale=[50,53,55,57,58,60,62,65,67,69,70,72,74,77,79,81,82,84,86];
const nearest=(n,lo=50,hi=86)=>scale.filter(v=>v>=lo&&v<=hi).reduce((a,b)=>Math.abs(b-n)<Math.abs(a-n)?b:a,62);
function linked(local,upstream){
 const p=clone(local),all=upstream.full,ownSteps=new Set(p.foreground.map(n=>n.step));
 const parentAt=step=>all.filter(n=>anchor(n)&&n.step<=step).at(-1)||upstream.foreground[0];
 // Give the incoming whole phrase a hierarchy: anchors are fixed; support may
 // make room for the actual left-side activity. Echo pairs keep their interval.
 const used=new Set(ownSteps),leftSupport=new Set(all.filter(support).map(n=>n.step));
 const echo=p.full.filter(n=>(n.layer||n.role)==='echo');
 if(echo.length===2){for(const shift of [0,1,-1,2,-2]){const ss=echo.map(n=>n.step+shift);if(ss.every(v=>v>=0&&v<16&&!used.has(v))&&(shift===-2||ss.every(v=>!leftSupport.has(v)))){echo.forEach((n,i)=>{n.step=ss[i];used.add(n.step);});break;}}}
 for(const n of p.full.filter(support)){
  const layer=n.layer||n.role;
  if(layer!=='echo'){
   const choices=[n.step,n.step+1,n.step-1,n.step+2,n.step-2].filter(s=>s>=(p.source[0]?.step||0)&&s<16&&!used.has(s));
   const fit=choices.find(s=>!leftSupport.has(s));if(fit!==undefined)n.step=fit;used.add(n.step);
  }
  n.dur=Math.min(n.dur,Math.max(.025,D-n.step*M.STEP-.018));
 }
 // Tonal information is inherited only when it exists. Rhythm input itself
 // still contains no inferred key. Current vocabulary remains D minor.
 for(const n of p.full){
  const parent=parentAt(n.sourceStep??n.step),pitch=parent&&pitched(parent);
  if(!Number.isFinite(pitch))continue;
  if(p.role==='voice'){
   const register=upstream.role==='voice'?12:0;
   const interval=anchor(n)?0:((n.layer==='echo')?0:2);
   n.note=nearest(pitch+register+interval,55,86);
  }else if(p.role==='harmony'){
   const incoming=parent.harmony?.slice(0,3)||[50,57,nearest(pitch,60,74)];
   n.harmony=incoming;
   n.notes=n.notes.length===3?incoming.slice():n.notes.map((_,i)=>incoming[(i+(anchor(n)?2:1))%3]);
   n.note=n.notes.at(-1);
  }else if(p.role==='dust')n.note=nearest(pitch+24,74,86);
 }
 // Update both lists together; foreground is never attenuated on every hop.
 p.foreground=p.full.filter(anchor).map(n=>clone(n));
 p.full.sort((a,b)=>a.step-b.step||(anchor(a)?-1:anchor(b)?1:0));
 return p;
}
class ArrangeModel{
 constructor(){this.revision=0;this.edges=[];this.wantedEdges=[];this.pending=null;this.clocks={};this.tiles={};
  for(const [id,role,phrase,present]of [['A','pulse',1,true],['B','harmony',2,false],['C','voice',1,false]]){
   this.clocks[id]={origin:0};this.tiles[id]={id,role,phrase,density:.5,ownSeed:[],fallback:[],useOwn:true,current:null,present,loop:false,clockId:id,memories:{pulse:1,voice:1,dust:1,harmony:2}};
  }
 }
 change(){this.revision++;this.pending=null;return this.revision;}
 setSeed(id,notes){const d=this.tiles[id];const q=P.clean(notes);if(!q.length)return false;d.ownSeed=clone(q);d.useOwn=true;d.fallback=clone(q);this.change();return true;}
 configure(id,patch){const d=this.tiles[id];if(!d)throw new Error('unknown tile');
  if(patch.role){if(!M.ROLES[patch.role])throw new Error('unknown role');d.memories[d.role]=d.phrase;d.role=patch.role;d.phrase=d.memories[d.role];}
  if(patch.phrase!==undefined){if(!Number.isInteger(patch.phrase)||patch.phrase<1||patch.phrase>3)throw new Error('invalid expression');d.phrase=patch.phrase;d.memories[d.role]=patch.phrase;}
  if(patch.density!==undefined)d.density=Math.max(0,Math.min(1,Number.isFinite(patch.density)?patch.density:.5));
  this.change();
 }
 present(id,value){const d=this.tiles[id];d.present=!!value;if(!value)d.loop=false;this.change();}
 setEdges(edges){const parents={},children={};for(const e of edges){if(!this.tiles[e.left]||!this.tiles[e.right]||e.left===e.right||parents[e.right]||children[e.left])throw new Error('invalid neighbor chain');parents[e.right]=e.left;children[e.left]=e.right;}
  for(const id of Object.keys(this.tiles)){let x=id,seen=new Set();while(parents[x]){if(seen.has(x))throw new Error('cycle');seen.add(x);x=parents[x];}}
  const filtered=edges.filter(e=>this.tiles[e.left].present&&this.tiles[e.right].present).map(e=>({left:e.left,right:e.right}));
  if(!same(filtered,this.wantedEdges)){this.wantedEdges=filtered;this.change();}
 }
 compile(){const plans={},clocks={},visiting=new Set(),parents=Object.fromEntries(this.wantedEdges.map(e=>[e.right,e.left]));
  const visit=id=>{if(id in plans)return plans[id];if(visiting.has(id))throw new Error('cycle');visiting.add(id);const d=this.tiles[id];if(!d.present){plans[id]=null;return null;}
   const upId=parents[id],up=upId?visit(upId):null;clocks[id]=up?clocks[upId]:d.clockId;
   const unchanged=d.current&&same(cfg(d.current),[d.role,d.phrase,d.density]);
   let plan,source;
   if(up){source=clone(up.rootSeed);plan=linked(M.compose(source,d.role,d.phrase,d.density),up);}
   else if(d.current&&unchanged&&(!d.useOwn||d.current.source)){
    plan=clone(d.current);source=clone(plan.rootSeed);plan.detached=true;
   }else{source=clone(d.useOwn?d.ownSeed:d.fallback);plan=M.compose(source,d.role,d.phrase,d.density);}
   if(!source.length){plans[id]=null;visiting.delete(id);return null;}
   plan.source=up?upId:null; // Input onsets are in rootSeed, not overloaded as source.
   plan.rootSeed=source;plan.role=d.role;plan.phrase=d.phrase;plan.density=d.density;
   if(up)plan.detached=false;
   plan.signature=JSON.stringify([plan.role,plan.phrase,plan.density,plan.source,plan.foreground,plan.full]);
   plans[id]=plan;visiting.delete(id);return plan;
  };
  for(const id of Object.keys(this.tiles))visit(id);
  return {revision:this.revision,plans,clocks,edges:clone(this.wantedEdges)};
 }
 stage(job,now){if(job.revision!==this.revision)return null;
  const changes=Object.keys(this.tiles).filter(id=>job.plans[id]?.signature!==this.tiles[id].current?.signature||job.clocks[id]&&job.clocks[id]!==this.tiles[id].clockId);
  let at=now+.045;
  // A connected component adopts its leftmost available musical clock. The
  // upstream sound is never rescheduled merely because a new right tile joins.
  const driver=changes.find(id=>this.tiles[id].loop)||changes.find(id=>Object.values(this.tiles).some(d=>d.loop&&job.clocks[id]===d.clockId));
  if(driver){const clock=job.clocks[driver]||this.tiles[driver].clockId,origin=this.clocks[clock].origin;at=origin+Math.ceil((now+.12-origin)/D)*D;}
  this.pending={...job,at,changes};return this.pending;
 }
 commit(now){if(!this.pending||now+1e-8<this.pending.at)return[];const job=this.pending;if(job.revision!==this.revision){this.pending=null;return[];}
  const updates=[];for(const id of job.changes){const d=this.tiles[id],old=d.current;d.current=job.plans[id];if(job.clocks[id])d.clockId=job.clocks[id];
   if(d.current?.source){d.fallback=clone(d.current.rootSeed);d.useOwn=false;}
   updates.push({id,old,plan:d.current,at:job.at});
  }
  this.edges=clone(job.edges);this.pending=null;return updates;
 }
 enableLoop(id,now){const d=this.tiles[id];if(!d.present||!d.current)return null;const clock=this.clocks[d.clockId],running=Object.values(this.tiles).some(x=>x.loop&&x.clockId===d.clockId);
  const start=running?clock.origin+Math.ceil((now+.10-clock.origin)/D)*D:now+.05;if(!running)clock.origin=start;d.loop=true;return start;
 }
 mute(id){this.tiles[id].loop=false;}
 phase(id,now){const d=this.tiles[id],origin=this.clocks[d.clockId].origin;return ((now-origin)%D+D)%D/D;}
}
root.ArrangeModel=ArrangeModel;root.ArrangeLinked=linked;
})(typeof window!=='undefined'?window:globalThis);
