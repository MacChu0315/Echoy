/* Echoy Pulse cooperation study. A bounded, explicit permission model.
   No DOM, clocks, wireless or audio in this module; all times are injected. */
(function(root){'use strict';
const BPM=96, STEP=60/BPM/4, BAR=16*STEP;
const clone=x=>JSON.parse(JSON.stringify(x)),clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const EXAMPLE=Object.freeze([{step:0,kind:'kick',vel:.78},{step:2,kind:'kick',vel:.69},{step:7,kind:'kick',vel:.72},{step:12,kind:'kick',vel:.76}].map(Object.freeze));
function clean(notes){const slots=new Map();for(const n of notes||[]){if(!Number.isFinite(n.step))continue;const step=clamp(Math.round(n.step),0,15),kind=['kick','rim','hat'].includes(n.kind)?n.kind:'kick';slots.set(step,{step,kind,vel:clamp(Number.isFinite(n.vel)?n.vel:.73,.16,.85),dur:kind==='kick'?.22:kind==='rim'?.09:.045,origin:n.origin==='partner'?'partner':'you'});}return [...slots.values()].sort((a,b)=>a.step-b.step);}
const signature=p=>JSON.stringify(clean(p).map(n=>[n.step,n.kind,Math.round(n.vel*100)]));
const hash=p=>clean(p).reduce((h,n)=>(h*31+n.step*17+{kick:1,rim:3,hat:5}[n.kind])>>>0,97);
function variation(pattern,seed,version=0,density=.5,style='develop'){
 const p=clean(pattern),source=clean(seed);if(!p.length)return {notes:[],reason:'empty'};
 let q=clone(p),reason='',h=(hash(source)+version*13)>>>0;
 const used=new Set(q.map(n=>n.step));const count=style==='fill'?1+(density>.75?1:0):1;
 // Stable base is never modified here. Every change returns a separate candidate.
 if(style==='fill'){
  const slots=[14,15,13,11,10,9,6,5,3,1].filter(s=>!used.has(s));
  for(let i=0;i<Math.min(count,slots.length);i++)q.push({step:slots[(h+i)%slots.length],kind:i?'hat':'rim',vel:.38+density*.13,origin:'partner'});
  reason='ending-fill';
 }else{
  const movable=q.map((n,i)=>i).filter(i=>i>0);const at=movable.length?movable[h%movable.length]:0;
  const op=style==='proposal'?version%3:version%4;
  if(op===0 && q.length>1){const n=q[at],sign=h%2?1:-1;let target=n.step+sign;
   if(target<=0||target>15||used.has(target))target=n.step-sign;
   if(target>0&&target<=15&&!used.has(target)){n.step=target;n.origin='partner';reason=target>p[at].step?'later-hit':'earlier-hit';}
  }else if(op===1 && q.length>2){q.splice(at,1);reason='more-space';}
  else if(op===2){q[at]={...q[at],kind:q[at].kind==='kick'?'rim':'kick',vel:q[at].kind==='kick'?.53:.72,origin:'partner'};reason='lighter-hit';}
  if(!reason){const slots=[3,6,10,14,15,5,9,13,2,7].filter(s=>!used.has(s));if(slots.length&&q.length<10){q.push({step:slots[h%slots.length],kind:'rim',vel:.46,origin:'partner'});reason='one-reply';}else {q[at]={...q[at],kind:q[at].kind==='rim'?'kick':'rim',vel:.57,origin:'partner'};reason='lighter-hit';}}
 }
 q=clean(q);
 if(signature(q)===signature(p)){const n=q[q.length-1];n.kind=n.kind==='kick'?'rim':'kick';n.vel=.54;n.origin='partner';reason='lighter-hit';}
 return {notes:q,reason};
}
function answer(seed,context,round,density){
 const base=clean(seed),v=variation(base,context.length?context:base,round,density,'develop');
 // Keep the input's backbone. Only one timing/timbre change per response.
 const notes=v.notes.map((n,i)=>({...n,kind:n.kind==='kick'?(i%2?'rim':'kick'):n.kind,vel:Math.min(n.vel,.65),origin:'partner'}));
 return {notes:clean(notes),reason:v.reason};
}
class PulseModel{
 constructor(mode='A'){
  if(!'ABCDE'.includes(mode)||mode.length!==1)throw new TypeError('Unknown cooperation mode');
  this.mode=mode;this.state=mode==='B'?'follow':'empty';this.seed=[];this.base=[];this.original=[];this.current=[];this.currentOwner='base';this.epoch=0;this.bar=-1;this.cursor=0;
  this.captureAt=0;this.captureEnd=0;this.raw=[];this.richness=.5;this.follow=true;this.followQueue=[];this.userTimes=[];this.userCount=0;this.followRecent=[];this.followEpoch=null;this.demo=[];
  this.held=false;this.nextChange=Infinity;this.holdBackup=null;this.round=0;this.changes=0;this.serial=0;this.proposal=null;this.lastCandidate=null;this.pending=null;this.pendingBar=Infinity;this.history=[];this.context=[];this.journal=[];this.notice='empty';this.lastNow=0;this.cancelToken=0;
 }
 log(type,detail=''){this.journal.unshift({type,detail,time:this.lastNow,bar:this.bar});this.journal=this.journal.slice(0,40);}
 backup(){return clone({seed:this.seed,base:this.base,original:this.original,current:this.current,currentOwner:this.currentOwner,round:this.round,context:this.context});}
 remember(){this.history.push(this.backup());if(this.history.length>12)this.history.shift();}
 clearPermission(){this.pending=null;this.pendingBar=Infinity;this.held=false;this.nextChange=Infinity;this.followQueue=[];this.demo=[];this.cancelToken++;}
 load(notes,now=0){const p=clean(notes);if(!p.length)return false;this.lastNow=now;this.remember();this.clearPermission();this.seed=clone(p);this.base=clone(p);this.original=clone(p);this.current=clone(p);this.proposal=null;this.lastCandidate=null;this.round=0;this.context=[];this.notice='sample';this.launch(now);return true;}
 launch(now){this.epoch=now+.08;this.bar=-1;this.cursor=0;this.pending=null;this.held=false;this.nextChange=Infinity;
  if(this.mode==='A'){const v=answer(this.seed,this.context,this.round,this.richness);this.current=v.notes;this.round++;this.context=clone(this.seed);this.currentOwner='reply';this.state='answer';this.log('reply',v.reason);}
  else if(this.mode==='B'){this.state='follow';}
  else{this.current=clone(this.base);this.currentOwner='base';this.state='playing';}
 }
 arm(now){this.lastNow=now;this.clearPermission();this.proposal=null;this.raw=[];this.state='armed';this.notice='armed';}
 cancel(now){this.lastNow=now;this.clearPermission();this.raw=[];this.state=this.seed.length?'paused':this.mode==='B'?'follow':'empty';this.current=clone(this.base);this.currentOwner='base';this.notice='canceled';}
 stop(now){this.lastNow=now;if(this.held)this.hold(false,now);this.clearPermission();this.raw=[];if(!(this.mode==='E'&&this.proposal?.heard))this.proposal=null;this.state=this.mode==='B'?'follow':this.seed.length?'paused':'empty';if(this.mode!=='A'){this.current=clone(this.base.length?this.base:this.current);this.currentOwner='base';}this.notice='paused';this.log('stop');}
 play(now){this.lastNow=now;if(this.mode==='B'){this.follow=true;this.notice='following';return true;}if(!this.seed.length)return false;this.clearPermission();this.epoch=now+.08;this.cursor=0;this.bar=-1;this.proposal=null;
  if(this.mode==='A'){this.state='answer';this.current=this.lastCandidate?.notes?clone(this.lastCandidate.notes):clone(this.current.length?this.current:this.seed);this.currentOwner='reply';}
  else{this.state='playing';this.current=clone(this.base);this.currentOwner='base';}return true;}
 tap(now,fromDemo=false){this.lastNow=now;
  if(this.mode==='B')return this.followTap(now,fromDemo);
  if(['empty','armed'].includes(this.state)||(this.mode==='A'&&['waiting','answer','paused'].includes(this.state))){this.clearPermission();this.raw=[];this.state='capture';this.captureAt=now;this.captureEnd=now+BAR;this.notice='recording';}
  if(this.state==='capture'&&now<this.captureEnd)this.raw.push({time:now-this.captureAt});
  return {at:now,step:0,kind:'kick',vel:.78,dur:.22,owner:'you',triggerAt:now};
 }
 followTap(now,fromDemo=false){if(!fromDemo)this.demo=[];this.userCount++;const previous=this.userTimes.at(-1);this.userTimes.push(now);this.userTimes=this.userTimes.slice(-8);if(this.followEpoch===null)this.followEpoch=now;
  const event={at:now,kind:'kick',vel:.78,dur:.22,step:Math.floor((now-this.followEpoch)/STEP)%16,owner:'you',triggerAt:now};this.followRecent.push(event);this.followRecent=this.followRecent.filter(e=>now-e.at<BAR);
  // A single input may authorize one short complement, never a generated chain.
  if(this.follow&&this.richness>.1&&previous!==undefined&&now-previous>.085&&now-previous<1.6){const interval=now-previous;const delay=clamp(interval*(this.richness>.7?.42:.5),.10,.28);const at=now+delay;
   this.followQueue=this.followQueue.filter(e=>e.at<now-.005||e.at>now+.04);this.followQueue.push({at,kind:this.richness<.4?'hat':'rim',vel:.29+this.richness*.16,dur:.065,owner:'partner',triggerAt:now,step:Math.floor((at-this.followEpoch)/STEP)%16});}
  this.state='follow';return event;
 }
 sampleFollow(now){this.clearPermission();this.follow=true;this.userTimes=[];this.followRecent=[];this.followEpoch=now+.1;this.demo=[0,.3125,1.09375,1.875].map(x=>now+.1+x);this.notice='demo';}
 finishCapture(now){if(!this.raw.length){this.cancel(now);return;}
  const p=clean(this.raw.map(n=>({step:Math.round(n.time/STEP),kind:'kick',vel:.74})));if(!p.length){this.cancel(now);return;}
  this.remember();this.seed=clone(p);this.base=clone(p);if(!this.original.length)this.original=clone(p);this.proposal=null;this.lastCandidate=null;this.raw=[];this.notice='captured';this.launch(now);
 }
 request(now){this.lastNow=now;if(!['C','E'].includes(this.mode)||!this.base.length||this.pending)return false;
  if(this.mode==='E'&&this.proposal)return false;if(this.state!=='playing')this.play(now);
  const v=variation(this.base,this.original,++this.serial,this.richness,this.mode==='C'?'fill':'proposal');
  this.proposal={...v,id:this.serial,heard:false};this.pending=this.mode==='C'?'fill':'proposal';this.pendingBar=Math.max(1,this.bar+1);this.notice='queued';this.log('requested',v.reason);return true;
 }
 adopt(now){this.lastNow=now;const c=this.proposal?.heard?this.proposal:this.lastCandidate;if(!c?.notes)return false;if(this.mode==='E'&&!this.proposal?.heard)return false;
  this.pending={type:'adopt',notes:clone(c.notes)};this.pendingBar=this.bar+1;this.notice='adopt-pending';if(this.state!=='playing')this.applyBase(c.notes,'adopt');return true;
 }
 reject(now){this.lastNow=now;this.pending=null;this.pendingBar=Infinity;this.proposal=null;this.notice='rejected';this.log('reject');}
 applyBase(notes,type){this.remember();this.base=clean(notes);this.current=clone(this.base);this.currentOwner='base';this.proposal=null;this.pending=null;this.pendingBar=Infinity;this.changes++;this.notice=type;this.log(type);}
 hold(down,now){this.lastNow=now;if(this.mode!=='D'||!this.base.length)return false;
  if(down){if(this.held)return false;if(this.state!=='playing')this.play(now);this.held=true;this.nextChange=Math.max(1,this.bar+1);this.holdBackup=this.backup();this.notice='holding';}
  else if(this.held){this.held=false;this.nextChange=Infinity;if(signature(this.base)!==signature(this.current)){if(this.holdBackup){this.history.push(this.holdBackup);this.history=this.history.slice(-12);}this.base=clone(this.current);}this.holdBackup=null;this.notice='held';this.log('hold-release');}
  return true;
 }
 undo(now){this.lastNow=now;if(this.pending){this.pending=null;this.pendingBar=Infinity;this.proposal=null;this.notice='canceled';return true;}if(!this.history.length)return false;
  const old=this.history.pop();if(this.state==='playing'){this.pending={type:'undo',data:old};this.pendingBar=this.bar+1;}else this.restore(old);return true;
 }
 restore(data){this.clearPermission();Object.assign(this,clone(data));this.proposal=null;this.currentOwner='base';if(!this.seed.length)this.state='empty';this.notice='undone';this.log('undo');}
 origin(now){if(!this.original.length)return false;this.lastNow=now;if(this.state==='playing'){this.pending={type:'adopt',notes:clone(this.original)};this.pendingBar=this.bar+1;}else this.applyBase(this.original,'origin');return true;}
 enterBar(bar){
  const previous=this.currentOwner;this.bar=bar;this.cursor=0;
  if(this.mode==='A')return;
  if(this.pending&&bar>=this.pendingBar){const action=this.pending;this.pending=null;this.pendingBar=Infinity;
   if(action==='fill'||action==='proposal'){if(this.proposal){this.current=clone(this.proposal.notes);this.currentOwner=action;this.proposal.heard=true;this.lastCandidate=clone(this.proposal);this.log(action,this.proposal.reason);}return;}
   if(action.type==='adopt'){this.applyBase(action.notes,'adopt');return;}
   if(action.type==='undo'){const data=action.data;this.restore(data);this.current=clone(this.base);return;}
  }
  if(this.mode==='D'){
   if(this.held&&bar>=this.nextChange){const v=variation(this.current,this.original,++this.serial,this.richness,'develop');this.current=v.notes;this.currentOwner='develop';this.changes++;this.nextChange=bar+2;this.log('develop',v.reason);}
   else if(!this.held){this.current=clone(this.base);this.currentOwner='base';}
  }else{this.current=clone(this.base);this.currentOwner='base';if(['fill','proposal'].includes(previous)){this.notice='returned';this.log('return-base');if(this.mode==='C')this.proposal=null;}}
 }
 tick(now){if(!Number.isFinite(now))return[];this.lastNow=now;let out=[];
  if(this.mode==='B'){
   while(this.demo.length&&this.demo[0]<=now){const at=this.demo.shift();if(now-at<.07)out.push(this.followTap(at,true));}
   const due=this.followQueue.filter(e=>e.at<=now+.018);this.followQueue=this.followQueue.filter(e=>e.at>now+.018);for(const e of due)if(e.at>=now-.07){out.push(e);this.followRecent.push(e);}this.followRecent=this.followRecent.filter(e=>now-e.at<BAR);return out;
  }
  if(this.state==='capture'&&now>=this.captureEnd)this.finishCapture(now);
  if(!['playing','answer'].includes(this.state)||now<this.epoch)return out;
  const bar=Math.floor((now-this.epoch)/BAR);
  if(this.mode==='A'&&bar>=1){this.state='waiting';this.lastCandidate={notes:clone(this.current),heard:true};this.notice='your-turn';this.log('reply-ended');return out;}
  if(bar!==this.bar)this.enterBar(bar);
  const start=this.epoch+bar*BAR,horizon=Math.min(now+.018,start+BAR-.00001);
  while(this.cursor<this.current.length){const n=this.current[this.cursor],at=start+n.step*STEP;if(at>horizon)break;this.cursor++;if(at>=now-.065)out.push({...n,at,owner:this.currentOwner==='base'?'base':'partner',bar,triggerAt:this.epoch});}
  return out;
 }
 phase(now){if(this.state==='capture')return {step:clamp(Math.floor((now-this.captureAt)/STEP),0,15),fraction:clamp((now-this.captureAt)/BAR,0,1),active:true};
  if(this.mode==='B'){const last=this.userTimes.at(-1),active=last!==undefined&&now-last<.46;return{step:this.followEpoch!==null?Math.floor(Math.max(0,now-this.followEpoch)/STEP)%16:-1,fraction:0,active};}
  const active=['playing','answer'].includes(this.state)&&now>=this.epoch,total=Math.max(0,(now-this.epoch)/STEP);return {step:Math.floor(total)%16,fraction:(total%16)/16,active};
 }
 score(now){if(this.state==='capture')return clean(this.raw.map(n=>({step:n.time/STEP,kind:'kick'})));if(this.mode==='B')return clean(this.followRecent.map(n=>({...n,origin:n.owner==='partner'?'partner':'you'})));return clone(this.current.length?this.current:this.base);}
 snapshot(){return clone({mode:this.mode,state:this.state,seed:this.seed,base:this.base,original:this.original,current:this.current,currentOwner:this.currentOwner,pending:this.pending,held:this.held,proposal:this.proposal,lastCandidate:this.lastCandidate,round:this.round,changes:this.changes,bar:this.bar,richness:this.richness,follow:this.follow,followQueue:this.followQueue,userCount:this.userCount,journal:this.journal});}
}
const api={PulseModel,clean,signature,variation,EXAMPLE,BPM,BAR,STEP};if(typeof module!=='undefined'&&module.exports)module.exports=api;root.PulseLab=api;
})(typeof window!=='undefined'?window:globalThis);


/* Browser sound adapter only. Each tile has its own gain, expression and wet tail.
 * The browser clock and final limiter are shared: this is NOT a firmware sync proof. */
(function(root){'use strict';
const midi=n=>440*Math.pow(2,(n-69)/12);
class DuijuSynth{
 constructor(ctx,destination){
  this.ctx=ctx;this.nodes=new Set();this.channels={};this.master=ctx.createGain();this.master.gain.value=.55;
  const limit=ctx.createDynamicsCompressor();limit.threshold.value=-12;limit.knee.value=12;limit.ratio.value=8;limit.attack.value=.003;limit.release.value=.15;
  this.master.connect(limit);limit.connect(destination||ctx.destination);
  this.noise=ctx.createBuffer(1,ctx.sampleRate*2,ctx.sampleRate);const ar=this.noise.getChannelData(0);let s=1187;
  for(let i=0;i<ar.length;i++){s=(s*16807)%2147483647;ar[i]=(s/2147483647*2-1);}
 }
 channel(id,pan=0){
  const c=this.ctx;
  if(!this.channels[id]){
   const input=c.createGain(),color=c.createBiquadFilter(),dry=c.createGain(),sum=c.createGain(),gain=c.createGain(),p=c.createStereoPanner();
   color.type='highshelf';color.frequency.value=1000;color.gain.value=0;dry.gain.value=.5;gain.gain.value=1;
   input.connect(color);color.connect(dry);dry.connect(sum);sum.connect(gain);gain.connect(p);p.connect(this.master);
   const send=c.createGain(),delay=c.createDelay(1),feedback=c.createGain(),damp=c.createBiquadFilter(),wet=c.createGain();
   delay.delayTime.value=.3125;feedback.gain.value=.18;wet.gain.value=.2;damp.type='lowpass';damp.frequency.value=2900;
   send.connect(delay);delay.connect(damp);damp.connect(feedback);feedback.connect(delay);damp.connect(wet);wet.connect(sum);
   this.channels[id]={input,color,dry,gain,p,send,delay,volume:.70,muted:false};
  }
  this.channels[id].p.pan.setTargetAtTime(pan,c.currentTime,.02);return this.channels[id].input;
 }
 env(target,t,peak,attack,release){target.gain.setValueAtTime(.00001,t);target.gain.exponentialRampToValueAtTime(Math.max(peak,.0001),t+attack);target.gain.exponentialRampToValueAtTime(.00001,t+attack+release);}
 note(id,e,t,pan=0){
  const c=this.ctx,dest=this.channel(id,pan),g=c.createGain(),nodes=[g],sources=[];
  g.connect(dest);const dur=e.dur||.2,expr=e.expression||0,stretch=1+expr*.45;
  const node=n=>{nodes.push(n);return n;};
  const source=(n,end,offset)=>{sources.push(n);n._duijuId=id;this.nodes.add(n);n.start(t,offset);n.stop(end);};
  if(e.kind==='kick'){
   const o=node(c.createOscillator());o.type='sine';o.frequency.setValueAtTime(128,t);o.frequency.exponentialRampToValueAtTime(47,t+.095*stretch);this.env(g,t,e.vel*.72,.004,.28*stretch);o.connect(g);source(o,t+.34*stretch);
  }else if(e.kind==='rim'){
   this.env(g,t,e.vel*.34,.001,.095*stretch);
   [238,517,1034].forEach((f,i)=>{const o=node(c.createOscillator()),v=node(c.createGain());o.frequency.value=f;v.gain.value=[.7,.23,.1][i];o.connect(v);v.connect(g);source(o,t+.13*stretch);});
  }else if(e.kind==='hat'){
   const n=node(c.createBufferSource());n.buffer=this.noise;const hp=node(c.createBiquadFilter());hp.type='highpass';hp.frequency.value=6500*(1+expr*.22);this.env(g,t,e.vel*.16,.001,.055*stretch);n.connect(hp);hp.connect(g);source(n,t+.08*stretch,.2);
  }else if(e.kind==='chord'){
   // Up to three locally synthesised pitches; no network audio and no new global bus.
   const pitches=(Array.isArray(e.notes)?e.notes:[e.note]).filter(Number.isFinite).slice(0,3);
   const rhythmic=e.articulation==='short'||e.articulation==='answer';
   const total=Math.max(rhythmic?.025:.07,Math.min(dur,e.maxDuration||2.45)),broken=e.articulation==='broken';
   const short=e.articulation==='short',answer=e.articulation==='answer',pickup=answer&&pitches.length===1;
   const attack=Math.min(total*.25,broken?.015:short?.008:answer?(pickup?.010:.018):e.articulation==='flow'?.13:.075);
   const release=Math.min(total*(short?.42:answer?.38:.32),broken?.12:short?.075:answer?.10:.23),hold=Math.max(attack+.001,total-release);
   const filter=node(c.createBiquadFilter());filter.type='lowpass';filter.Q.value=.48;
   filter.frequency.setValueAtTime((broken?2900:short?2700:answer?2350:1750)*(1+expr*.4),t);
   filter.frequency.exponentialRampToValueAtTime((broken?1700:short?1050:answer?1250:1100)*(1+expr*.3),t+total);
   filter.connect(g);g.connect(this.channels[id].send);
   // The gain is per chord, not per voice. Adding a third pitch does not triple output.
   const peak=Math.max(.0001,e.vel*(broken||pickup?.26:.32)/Math.sqrt(Math.max(1,pitches.length)));
   g.gain.setValueAtTime(.00001,t);g.gain.linearRampToValueAtTime(peak,t+attack);
   g.gain.linearRampToValueAtTime(peak*(broken?.64:short?.46:answer?.60:.82),t+hold);
   g.gain.exponentialRampToValueAtTime(.00001,t+total);
   for(const pitch of pitches){
    const fundamental=node(c.createOscillator()),warmth=node(c.createOscillator()),v=node(c.createGain());
    fundamental.type='sine';fundamental.frequency.value=midi(pitch);fundamental.connect(filter);
    warmth.type='triangle';warmth.frequency.value=midi(pitch);v.gain.value=broken?.15:.22;
    warmth.connect(v);v.connect(filter);source(fundamental,t+total+.01);source(warmth,t+total+.01);
   }
  }else if(e.kind==='tone'){
   const filter=node(c.createBiquadFilter());filter.type='lowpass';filter.frequency.setValueAtTime(2400,t);filter.frequency.exponentialRampToValueAtTime(700,t+.5);filter.Q.value=.45;filter.connect(g);
   this.env(g,t,e.vel*.29,.012,dur+.38);g.connect(this.channels[id].send);
   [[1,1],[2,.22],[3,.07]].forEach(([mul,level])=>{const o=node(c.createOscillator()),v=node(c.createGain());o.type='sine';o.frequency.value=midi(e.note)*mul;v.gain.value=level;o.connect(v);v.connect(filter);source(o,t+dur+.46);});
  }else{
   this.env(g,t,e.vel*.3,.014,dur+.16);g.connect(this.channels[id].send);
   const n=node(c.createBufferSource()),band=node(c.createBiquadFilter());n.buffer=this.noise;band.type='bandpass';band.frequency.value=midi(e.note)*1.7;band.Q.value=5.5;n.connect(band);band.connect(g);source(n,t+dur+.23,.65);
   const o=node(c.createOscillator()),v=node(c.createGain());o.frequency.value=midi(e.note);v.gain.value=.19;o.connect(v);v.connect(g);source(o,t+dur+.23);
  }
  let remaining=sources.length;
  sources.forEach(n=>n.onended=()=>{this.nodes.delete(n);if(--remaining===0)nodes.forEach(x=>{try{x.disconnect();}catch(_){}});});
 }
 setVolume(v){this.master.gain.setTargetAtTime(Math.max(0,Math.min(.85,v)),this.ctx.currentTime,.025);}
 updateGain(id){const ch=this.channels[id];ch.gain.gain.setTargetAtTime(ch.muted?0:ch.volume/.70,this.ctx.currentTime,.018);}
 setChannelVolume(id,v){if(!this.channels[id])this.channel(id);this.channels[id].volume=Math.max(0,Math.min(1,v));this.updateGain(id);}
 expression(id,value,reference){if(!this.channels[id])this.channel(id);this.channels[id].color.gain.setTargetAtTime((value-reference)*10,this.ctx.currentTime,.025);}
 mute(id,value){if(!this.channels[id])this.channel(id);this.channels[id].muted=value;this.updateGain(id);if(value)this.stopDevice(id);}
 stopDevice(id){for(const n of this.nodes)if(n._duijuId===id){try{n.stop(this.ctx.currentTime+.03);}catch(_){}}}
 stop(){for(const n of this.nodes){try{n.stop(this.ctx.currentTime+.025);}catch(_){}}}
}
root.DuijuSynth=DuijuSynth;
})(window);


/* One-bar response A/B. Pure functions; no rendering, clocks, network or random input.
   A is the archived first-round Pulse A rule. B keeps all recorded attacks intact. */
(function(root){'use strict';
const old=root.PulseLab||(typeof require==='function'?require('../baseline/model.js'):null);
const clamp=(n,a,b)=>Math.max(a,Math.min(b,Number.isFinite(n)?n:a));
const clean=old.clean,STEP=old.STEP,DURATION=old.BAR;
function quantize(times){return clean((times||[]).filter(t=>Number.isFinite(t)&&t>=0&&t<DURATION).map(t=>({step:Math.round(t/STEP),kind:'kick',vel:.74})));}
function layered(input,density=.5){
 const source=clean(input);if(!source.length)return[];
 density=clamp(density,0,1);
 const anchors=source.map(n=>({...n,role:'anchor',sourceStep:n.step,origin:'you'}));
 const additions=[],occupied=new Set(source.map(n=>n.step+':'+n.kind));
 const anchorSteps=new Set(source.map(n=>n.step));
 const minVelocity=Math.min(...source.map(n=>n.vel));
 const add=(step,kind,velocity,role,sourceStep=null)=>{
  step=Math.round(step);if(step<0||step>15||occupied.has(step+':'+kind))return false;
  // A main drum attack stays a single perceptible anchor, not doubled by support.
  if(anchorSteps.has(step))return false;
  const vel=Math.min(velocity,minVelocity*.82);
  occupied.add(step+':'+kind);additions.push({step,kind,vel,dur:kind==='kick'?.22:kind==='rim'?.09:.045,origin:'partner',role,sourceStep});return true;
 };
 const head=source[0].step,last=source.at(-1).step;
 // Preserve the shortest *adjacent* input pair. Revoice it softly later in the bar.
 const pairs=source.slice(1).map((n,i)=>({first:source[i],last:n,gap:n.step-source[i].step})).filter(p=>p.gap>0&&p.gap<=3).sort((a,b)=>a.gap-b.gap||a.first.step-b.first.step);
 if(pairs.length){const pair=pairs[0];const candidates=[head+8,head+4,head+6,head+10,head+12];
  const at=candidates.find(s=>s>pair.last.step&&s+pair.gap<=14&&!anchorSteps.has(s)&&!anchorSteps.has(s+pair.gap));
  if(at!==undefined){add(at,'rim',.53,'echo',pair.first.step);add(at+pair.gap,'rim',.47,'echo',pair.last.step);}
 }
 // Only a single attack does not specify a tempo. This is an explicit fixed-grid
 // proposal at the demo's 96 BPM, not an inference from that one tap.
 add(head+8,'kick',.46,'support',head);
 const closing=last<4?head+12:last<12?Math.min(14,Math.ceil((last+2)/2)*2):null;
 if(closing!==null)add(closing,'rim',.49,'ending',last);
 // A sparse supporting pulse; source-derived pair always has priority over grid.
 for(const s of [head+4,head+12])add(s,'rim',.42,'support',null);
 const pulse=pairs.length&&pairs[0].gap===3?3:2;
 for(let s=head+pulse;s<16;s+=pulse)add(s,'hat',s%4===2?.40:.32,'support',null);
 // At the high end only, short lead-in/cadence details; no autonomous extension.
 if(last<14)add(14,'rim',.41,'ending',last);
 for(const s of [head+7,head+11,head+15,head+5,head+9,head+3,head+13,head+1])add(s,'hat',.26,'detail',null);
 const budget=Math.min(26-anchors.length,4+Math.round(density*6));
 return [...anchors,...additions.slice(0,budget)].sort((a,b)=>a.step-b.step||(a.role==='anchor'?-1:b.role==='anchor'?1:0));
}
function buildPair(input,density=.5){const source=clean(input);if(!source.length)return {source:[],sparse:[],layered:[],duration:DURATION};
 const previous=new old.PulseModel('A');previous.richness=clamp(density,0,1);previous.load(source,0);
 return {source,sparse:previous.current.map(n=>({...n})),layered:layered(source,density),duration:DURATION};
}
function stats(values){let energy=0,peak=0;for(const n of values){energy+=n*n;peak=Math.max(peak,Math.abs(n));}return {rms:Math.sqrt(energy/Math.max(1,values.length)),peak};}
function normalise(buffers){const a=stats(buffers.sparse),b=stats(buffers.layered);let target=.045;
 for(const s of [a,b])if(s.rms>1e-10&&s.peak>0)target=Math.min(target,.65*s.rms/s.peak);
 const result={metrics:{targetRms:target,before:{sparse:a,layered:b},after:{},gains:{}}};
 for(const key of ['sparse','layered']){const s=key==='sparse'?a:b,g=s.rms>1e-10?target/s.rms:0;const x=Float32Array.from(buffers[key],v=>v*g);result[key]=x;result.metrics.gains[key]=g;result.metrics.after[key]=stats(x);}
 return result;
}
const api={buildPair,layered,quantize,normalise,stats,STEP,DURATION,PRESETS:{one:[0],close:[0,2],spaced:[0,8],three:[0,2,10],original:[0,2,7,12]}};
if(typeof module!=='undefined'&&module.exports)module.exports=api;root.ReplyAB=api;
})(typeof window!=='undefined'?window:globalThis);


/* Same rhythm, role-specific accompaniment. No DOM, clocks, network or randomness.
 * Input taps carry timing, NOT pitch. Tonal pitches below are a system proposal
 * inside the original D-minor vocabulary. Each input onset has a foreground event.
 */
(function(root){'use strict';
const A=root.ReplyAB||(typeof require==='function'?require('../ab-src/reply.js'):null);
const P=root.PulseLab||(typeof require==='function'?require('../baseline/model.js'):null);
const ROLES={
 pulse:{name:'脉冲',en:'Pulse',color:'#d95535',phrases:['重音','切分','留白'],english:['Accent','Syncopation','Space'],defaultPhrase:1,desc:['用鼓点的不同附和方式，把你的节奏衬托起来。','Layered drum support around your rhythm.']},
 voice:{name:'声线',en:'Voice',color:'#496da1',phrases:['短句','轻答','长线'],english:['Short phrase','Light reply','Long line'],defaultPhrase:1,desc:['用旋律接住你的敲击。','Your rhythm, given a melodic voice.']},
 dust:{name:'微尘',en:'Dust',color:'#7b8452',phrases:['颗粒','点缀','余韵'],english:['Grains','Touches','Trails'],defaultPhrase:1,desc:['让敲击生出颗粒与余韵。','Small grains and trails around your taps.']},
 harmony:{name:'和声',en:'Harmony',color:'#aa7b3d',phrases:['短和弦','分解','接句'],english:['Short chords','Arpeggio','Answer'],defaultPhrase:2,desc:['以短奏、分解和小句附和。','Short chords, broken notes and replies.']}
};
const DESCRIPTIONS={
 voice:[['主音之间用短旋律连接，句尾收住。','Short melodic links between your attacks.'],['较短、较轻的回应，保留清楚的空隙。','Lighter replies with shorter notes and room.'],['拉长主音、加入柔和连接，不抹掉起音。','Sustained main notes and gentle connections.']],
 dust:[['清楚的颗粒主干，周围有短小粒簇。','Distinct grains surrounded by small clusters.'],['亮一些的点缀错落出现，不把空隙填满。','Bright touches, scattered with deliberate gaps.'],['主音后留衰减的回声与较长的尾音。','Fading repeats and longer tails after each grain.']],
 harmony:[['每次短和弦有音高走向，及时收住。','Moving chord voicings with short endings.'],['和弦中的音依次出现，接住敲击时位。','Chord tones unfold around your attack times.'],['主干之后用小句接话，最后短和弦落下。','Small pickups answer, then close with a chord.']],
 pulse:[['保留你熟悉的分层鼓点，并更明确地强调落点。','The familiar layered pulse, with clearer accents.'],['在反拍与空隙上做更灵活的附和，保留主干。','More syncopated support around the offbeats.'],['减少填充，只留下有意义的回应与收尾。','Less filling, more deliberate space and endings.']]
};
for(const r of Object.values(ROLES)){Object.freeze(r.phrases);Object.freeze(r.english);Object.freeze(r);}
Object.freeze(ROLES);
const clone=x=>JSON.parse(JSON.stringify(x)),clamp=(x,a,b)=>Math.max(a,Math.min(b,Number.isFinite(x)?x:a));
const SCALE=[62,65,67,69,70,72,74];
const VOICINGS=[[50,57,65],[53,60,69],[55,62,70],[50,57,65],[48,55,67],[53,60,69]];
function voicePitch(source,i){if(i===0)return 62;const gap=source[i].step-source[i-1].step;const contour=[0,3,1,2,4,3,1,0];let ix=contour[i%contour.length];if(gap>=6)ix=Math.max(0,ix-1);return SCALE[ix];}
function planSupport(source,role,phrase){
 const occupied=new Set(source.map(n=>n.step)),slots=[],head=source[0].step,last=source.at(-1).step;
 const add=(step,layer,sourceStep=null)=>{if(step<0||step>=16||occupied.has(step))return false;occupied.add(step);slots.push({step,layer,sourceStep});return true;};
 // First retain the audible relation of a close pair; no hash picks arbitrary notes.
 const pairs=source.slice(1).map((n,i)=>({first:source[i].step,last:n.step,gap:n.step-source[i].step})).filter(p=>p.gap>0&&p.gap<=3).sort((a,b)=>a.gap-b.gap||a.first-b.first);
 if(pairs.length){const q=pairs[0],at=[head+8,head+4,head+6,head+10].find(s=>s>q.last&&s+q.gap<15&&!occupied.has(s)&&!occupied.has(s+q.gap));if(at!==undefined){add(at,'echo',q.first);add(at+q.gap,'echo',q.last);}}
 // A bounded cadence is present even for one tap; rhythm-only input does not tell
 // us a harmonic cadence, so this is explicitly the instrument's proposal.
 const end=[head+14,head+12,head+10,head+8,head+6,head+4,head+2].find(s=>s<16&&s>last&&!occupied.has(s));
 if(end!==undefined)add(end,'ending',last);
 // Preferred support placements have a stable relationship to the recorded head.
 const routes=role==='voice'?(phrase===1?[4,6,12,3,11,9,1,7,13,15]:phrase===2?[5,11,3,13,7,9,1,15,4,12]:[6,12,4,9,3,11,2,13,7,15]):
  role==='dust'?(phrase===1?[1,5,9,3,13,7,11,15,4,12]:phrase===2?[4,11,7,13,6,10,1,15]:[2,4,8,11,6,12,3,13,7,15]):
  phrase===1?[4,12,6,10,3,7,11,15,2,9]:phrase===2?[3,6,10,13,4,7,11,15,2,5]:[9,11,13,5,7,3,12,6,4,15];
 for(const off of routes){const at=head+off;const nearest=source.reduce((best,n)=>Math.abs(n.step-at)<Math.abs(best.step-at)?n:best,source[0]);add(at,'support',nearest.step);}
 // Fine particle subdivisions supplement the display's coarse 16 cells only
 // at the richer end; input itself retains the shared 16-step capture rule.
 if(role==='dust'&&phrase===1)for(const n of source){add(n.step+.5,'detail',n.step);add(n.step+1.5,'detail',n.step);}
 return slots;
}

function composePulse(source,phrase=1,density=.5){
 const d=clamp(density,0,1);
 const full=A.layered(source,d).map(n=>({...n}));
 if(!full.length)return {role:'pulse',phrase,density:d,source,foreground:[],full:[],duration:A.DURATION};
 const anchors=full.filter(n=>n.role==='anchor').map(n=>({...n}));
 if(phrase===1)return {role:'pulse',phrase,density:d,source,foreground:anchors,full,duration:A.DURATION};
 const occupied=new Set(anchors.map(n=>`${n.step}:${n.kind}`));
 const support=[];
 const add=(step,kind,vel,role='support',sourceStep=null)=>{
  step=Math.round(step);if(step<0||step>15)return false;
  const key=`${step}:${kind}`;if(occupied.has(key))return false;
  occupied.add(key);support.push({step,kind,vel,dur:kind==='kick'?.22:kind==='rim'?.09:.045,origin:'partner',role,sourceStep});return true;
 };
 const head=source[0].step,last=source.at(-1).step;
 const baseSupports=full.filter(n=>n.role!=='anchor');
 if(phrase===2){
  baseSupports.filter(n=>n.role==='echo'||n.role==='ending').forEach(n=>add(n.step,n.kind,Math.min((n.vel||.3)*.98,.42),n.role,n.sourceStep));
  const routes=[3,6,10,13,7,11,15,5,9,1,14,12,4,8,2];
  const budget=3+Math.round(d*5);
  for(const off of routes){
   const at=head+off;if(at>15||(at<=last&&off<6))continue;
   const nearest=source.reduce((best,n)=>Math.abs(n.step-at)<Math.abs(best.step-at)?n:best,source[0]);
   const kind=(off%4===3||off%4===1)?'hat':'rim';
   const vel=kind==='hat'?(d>.62?.30:.24):.34;
   add(at,kind,vel,'support',nearest.step);
   if(support.length>=budget)break;
  }
  const phraseFull=[...anchors,...support].sort((a,b)=>a.step-b.step||(a.role==='anchor'?-1:b.role==='anchor'?1:0));
  return {role:'pulse',phrase,density:d,source,foreground:anchors,full:phraseFull,duration:A.DURATION};
 }
 const chosen=[];
 const pushIf=pred=>baseSupports.filter(pred).forEach(n=>chosen.push(n));
 pushIf(n=>n.role==='echo');
 pushIf(n=>n.role==='ending');
 if(d>.45)pushIf(n=>n.role==='support'&&n.kind==='rim');
 if(d>.72)pushIf(n=>n.role==='detail'||(n.role==='support'&&n.kind==='hat'));
 chosen.forEach((n,idx)=>{if(idx<4+Math.round(d*2))add(n.step,n.kind,Math.min(n.vel||.3,n.kind==='hat'?.18:.30),n.role,n.sourceStep);});
 const phraseFull=[...anchors,...support].sort((a,b)=>a.step-b.step||(a.role==='anchor'?-1:b.role==='anchor'?1:0));
 return {role:'pulse',phrase,density:d,source,foreground:anchors,full:phraseFull,duration:A.DURATION};
}

function compose(input,role='voice',phrase=1,density=.5){
 const meta=ROLES[role];if(!meta||!Number.isInteger(phrase)||phrase<1||phrase>meta.phrases.length)throw new RangeError('Unknown role or expression');
 const source=P.clean(input),d=clamp(density,0,1);
 if(!source.length)return {role,phrase,density:d,source:[],foreground:[],full:[],duration:A.DURATION};
 if(role==='pulse')return composePulse(source,phrase,d);
 const foreground=source.map((n,i)=>{
  const next=source[i+1]?.step??16,space=(next-n.step)*A.STEP,base={step:n.step,vel:n.vel,layer:'anchor',sourceStep:n.step,origin:'you',expression:0};
  if(role==='voice')return {...base,kind:'tone',note:voicePitch(source,i),dur:Math.min(Math.max(.05,space-.025),phrase===3?.62:phrase===2?.12:.24)};
  if(role==='dust')return {...base,kind:'grain',note:[81,86,84,89,86][i%5]+(phrase===2?5:0),dur:Math.min(Math.max(.045,space-.025),phrase===1?.085:phrase===2?.14:.46)};
  const harmony=VOICINGS[i%VOICINGS.length].slice(),notes=phrase===1?harmony:phrase===2?[harmony[2]]:[harmony[2]];
  return {...base,kind:'chord',notes,note:notes.at(-1),harmony,articulation:phrase===1?'short':phrase===2?'broken':'answer',dur:Math.min(Math.max(.05,space-.025),phrase===1?.19:phrase===2?.23:.15),maxDuration:Math.min(.27,Math.max(.05,space-.025))};
 });
 const slots=planSupport(source,role,phrase),minVel=Math.min(...foreground.map(n=>n.vel));
 const budget=Math.min(32-foreground.length,role==='voice'?(phrase===1?4+Math.round(d*5):phrase===2?3+Math.round(d*4):3+Math.round(d*4)):role==='dust'?(phrase===1?4+Math.round(d*8):phrase===2?3+Math.round(d*4):4+Math.round(d*5)):4+Math.round(d*6));
 // For grains, start introducing subdivisions at high richness while preserving
 // a close-pair echo and cadence. The original user's anchors are never removed.
 let chosen=slots.slice(0,budget);
 if(role==='dust'&&phrase===1&&d>.7){const fine=slots.filter(s=>s.layer==='detail').slice(0,Math.max(1,Math.floor(d*3)));chosen=[...chosen.slice(0,Math.max(0,budget-fine.length)),...fine];}
 const support=chosen.map((s,j)=>{
  const index=Math.max(0,source.findIndex(n=>n.step===s.sourceStep)),parent=foreground[index],end=s.layer==='ending';
  let vel=(s.layer==='echo'?.48:end?.44:s.layer==='detail'?.28:.36);vel=Math.min(vel,minVel*.78);
  const base={...s,vel,origin:'partner',expression:0};
  const remaining=Math.max(.035,A.DURATION-s.step*A.STEP-.018);
  if(role==='voice'){
   const note=s.layer==='echo'?parent.note: end?62: SCALE[(Math.max(0,SCALE.indexOf(parent.note))+(phrase===2?2:1)+(j%2))%SCALE.length];
   return {...base,kind:'tone',note:phrase===3&&!end?note-12:note,dur:Math.min(remaining,phrase===1?.16:phrase===2?.085:.32),vel:phrase===3?vel*.8:vel};
  }
  if(role==='dust')return {...base,kind:'grain',note:phrase===3?parent.note:[86,93,89,96,84,91][j%6]+(phrase===2?5:0),dur:Math.min(remaining,phrase===1?.055:phrase===2?.08:.32),vel:phrase===3?Math.min(vel,.48*Math.exp(-Math.max(0,s.step-parent.step)/18)):vel};
  let harmonic=parent.harmony.slice();
  let notes;
  if(phrase===1){const v=VOICINGS[(index+1+j%2)%VOICINGS.length];harmonic=v.slice();notes=end?v.slice():j%2?[v[1],v[2]]:[v[2]];}
  else if(phrase===2){const tones=[harmonic[0]+12,harmonic[1],harmonic[2],harmonic[1]+12];notes=[s.layer==='echo'?parent.note:tones[j%4]];}
  else notes=end?[50,57,65]:[s.layer==='echo'?parent.note: harmonic[(j+1)%3]+(j%2===0?12:0)];
  const dur=Math.min(remaining,phrase===1?.12:phrase===2?.20:end?.24:.11);
  return {...base,kind:'chord',note:notes.at(-1),notes,harmony:phrase===3&&end?[50,57,65]:harmonic,articulation:phrase===2?'broken':phrase===1?'short':'answer',dur,maxDuration:Math.min(remaining,.30)};
 });
 const full=[...foreground,...support].sort((a,b)=>a.step-b.step||(a.layer==='anchor'?-1:b.layer==='anchor'?1:0));
 return {role,phrase,density:d,source,foreground,full,duration:A.DURATION};
}
const api={ROLES,DESCRIPTIONS,compose,STEP:A.STEP,DURATION:A.DURATION,quantize:A.quantize,PRESETS:A.PRESETS};
root.RoleAccompaniment=api;if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(typeof window!=='undefined'?window:globalThis);


(function(root){'use strict';
const {buildPair,quantize,normalise,stats,PRESETS,STEP,DURATION}=root.ReplyAB;const SR=24000;
const ICON={play:'<path d="m8 5 11 7-11 7Z" fill="currentColor" stroke="none"/>',stop:'<rect x="6" y="6" width="12" height="12" rx="1" fill="currentColor" stroke="none"/>',record:'<circle cx="12" cy="12" r="6" fill="currentColor" stroke="none"/>',back:'<path d="m14 5-7 7 7 7M7 12h14"/>',gear:'<path d="m9 3-.6 2.5-2 1.2L4 6l-2 3 2 1.8v2.4L2 15l2 3 2.4-.7 2 1.2L9 21h4l.6-2.5 2-1.2 2.4.7 2-3-2-1.8v-2.4L20 9l-2-3-2.4.7-2-1.2L13 3Z"/><circle cx="11" cy="12" r="3"/>',speaker:'<path d="M10 5 5 9H2v6h3l5 4V5Zm5 3c3 2 3 6 0 8m3-11c5 4 5 10 0 14"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9 8a3 3 0 0 1 6 1c0 2-3 2-3 5m0 3v.1"/>',next:'<path d="m9 5 7 7-7 7"/>',cross:'<path d="m6 6 12 12M18 6 6 18"/>',wave:'<path d="M3 13v1m4-6v10m5-15v18m5-14v10m4-6v2"/>',download:'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>'};
const ico=n=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[n]||ICON.wave}</svg>`;
const safe=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
class AudioAB{
 constructor(){this.ctx=null;this.master=null;this.live=null;this.volume=.65;this.promise=null;this.source=null;this.gate=null;this.cache=new Map();this.audit=[];this.starts=0;this.stops=0;}
 async ensure(){if(this.promise)return this.promise;this.promise=(async()=>{if(!this.ctx){const AC=root.AudioContext||root.webkitAudioContext;if(!AC)throw new Error('AudioContext unavailable');this.ctx=new AC();this.master=this.ctx.createGain();this.master.gain.value=this.volume;this.master.connect(this.ctx.destination);this.live=new root.DuijuSynth(this.ctx,this.master);this.live.setVolume(.55);}await this.ctx.resume();if(this.ctx.state!=='running')throw new Error('Audio output blocked');})();try{await this.promise;}finally{this.promise=null;}}
 volumeTo(v){this.volume=Math.max(0,Math.min(1,v));if(this.master)this.master.gain.setTargetAtTime(this.volume,this.ctx.currentTime,.015);}
 tap(){const t=this.ctx.currentTime+.003;this.live.note('finger',{kind:'kick',vel:.78,dur:.22,note:38,expression:0},t,0);this.audit.push({kind:'finger',at:t});}
 async renderNotes(notes){const Offline=root.OfflineAudioContext||root.webkitOfflineAudioContext;if(!Offline)throw new Error('OfflineAudioContext unavailable');
  const c=new Offline(1,Math.round(SR*DURATION),SR),s=new root.DuijuSynth(c);s.setVolume(.55);
  for(const n of notes)s.note('reply',{...n,note:n.kind==='kick'?38:n.kind==='rim'?50:84,expression:0},n.step*STEP,0);
  const data=new Float32Array((await c.startRendering()).getChannelData(0));
  const release=Math.round(.018*SR);for(let i=0;i<release;i++)data[data.length-release+i]*=(release-1-i)/release;
  return data;
 }
 async prepare(seed,density){const key=JSON.stringify([seed,density]);if(this.cache.has(key))return this.cache.get(key);
  const pair=buildPair(seed,density);if(!pair.source.length)throw new Error('No rhythm');
  const [a,b,source]=await Promise.all([this.renderNotes(pair.sparse),this.renderNotes(pair.layered),this.renderNotes(pair.source)]);
  const matched=normalise({sparse:a,layered:b});const srcStat=stats(source);const srcGain=srcStat.rms?Math.min(.65/srcStat.peak,matched.metrics.targetRms/srcStat.rms):0;
  const data={key,pair,arrays:{sparse:matched.sparse,layered:matched.layered,source:Float32Array.from(source,x=>x*srcGain)},metrics:matched.metrics,density,sampleRate:SR,duration:DURATION};
  this.cache.set(key,data);if(this.cache.size>8)this.cache.delete(this.cache.keys().next().value);return data;
 }
 play(data,kind,done){this.stop();const buffer=this.ctx.createBuffer(1,data.arrays[kind].length,SR);buffer.getChannelData(0).set(data.arrays[kind]);const source=this.ctx.createBufferSource(),gate=this.ctx.createGain();source.buffer=buffer;source.connect(gate);gate.connect(this.master);source.onended=()=>{source.disconnect();gate.disconnect();if(this.source===source){this.source=null;this.gate=null;done();}};
  const start=this.ctx.currentTime+.028;this.source=source;this.gate=gate;source.start(start);this.starts++;this.audit.push({kind,start,end:start+DURATION,sourceKey:data.key,eventCount:data.pair[kind==='source'?'source':kind].length});return start;
 }
 stop(){this.live?.stop();if(this.source){const s=this.source,g=this.gate;this.source=null;this.gate=null;s.onended=()=>{s.disconnect();g.disconnect();};g.gain.cancelScheduledValues(this.ctx.currentTime);g.gain.setValueAtTime(g.gain.value,this.ctx.currentTime);g.gain.linearRampToValueAtTime(0,this.ctx.currentTime+.01);try{s.stop(this.ctx.currentTime+.012);}catch(_){}}this.stops++;}
}

class RoleAudio extends AudioAB{
 constructor(){super();this.roleCache=new Map();}
 async renderRoleNotes(notes,role){
  if(role==='pulse')return this.renderNotes(notes);
  const Offline=root.OfflineAudioContext||root.webkitOfflineAudioContext;
  if(!Offline)throw new Error('Offline audio unavailable');
  const context=new Offline(1,Math.round(SR*DURATION),SR),synth=new root.DuijuSynth(context);synth.setVolume(.55);
  for(const n of notes)synth.note('reply',{...n,expression:0},n.step*STEP,0);
  const data=new Float32Array((await context.startRendering()).getChannelData(0));
  const release=Math.round(.06*SR);for(let i=0;i<release;i++)data[data.length-release+i]*=(release-1-i)/release;
  return data;
 }
 async prepareRole(seed,role,phrase,density){
  const key=JSON.stringify([seed,role,phrase,density]);if(this.roleCache.has(key))return this.roleCache.get(key);
  const plan=root.RoleAccompaniment.compose(seed,role,phrase,density);if(!plan.source.length)throw new Error('No rhythm');
  let arrays,metrics;
  if(role==='pulse'&&phrase===1){
   const original=await super.prepare(seed,density);
   // Phrase 1 keeps the accepted Pulse B rendering path as the accent reference.
   arrays={full:original.arrays.layered,foreground:original.arrays.source,source:original.arrays.source};metrics={reference:'Original Pulse B',...original.metrics};
  }else{
   const [main,full,raw]=await Promise.all([this.renderRoleNotes(plan.foreground,role),this.renderRoleNotes(plan.full,role),this.renderNotes(plan.source)]);
   const matched=normalise({sparse:main,layered:full}),rs=stats(raw),gain=rs.rms?Math.min(.65/rs.peak,matched.metrics.targetRms/rs.rms):0;
   arrays={full:matched.layered,foreground:matched.sparse,source:Float32Array.from(raw,n=>n*gain)};metrics=role==='pulse'?{reference:'Pulse layered accompaniment',...matched.metrics}:matched.metrics;
  }
  const data={key,plan,arrays,role,phrase,density,metrics,duration:DURATION,sampleRate:SR,
    pair:{full:plan.full,foreground:plan.foreground,source:plan.source}};
  this.roleCache.set(key,data);if(this.roleCache.size>24)this.roleCache.delete(this.roleCache.keys().next().value);
  return data;
 }
}
root.RoleAudio=RoleAudio;root.RoleUI={ico,safe};
})(window);


/* Procedural role art. Event positions and note marks are real plan data. */
(function(root){'use strict';
function draw(canvas,role,notes=[],progress=0,active=false,energy=0){
 if(!canvas)return;const ctx=canvas.getContext('2d');if(!ctx)return;const w=+canvas.dataset.w||300,h=+canvas.dataset.h||204;
 ctx.setTransform(canvas.width/w,0,0,canvas.height/h,0,0);ctx.clearRect(0,0,w,h);ctx.save();ctx.scale(w/300,h/204);ctx.lineCap='round';
 const color=root.RoleAccompaniment.ROLES[role].color,now=progress*16,step=Math.floor(now),anchor=n=>n.layer==='anchor'||n.role==='anchor'||(!n.layer&&!n.role),random=n=>{const v=Math.sin(n*127.1+311.7)*43758.5453;return v-Math.floor(v);};
 if(role==='pulse'){
  const x=150,y=99;ctx.strokeStyle='#d3d7c9';ctx.lineWidth=1;for(const r of [39,59,79]){ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.stroke();}
  for(let i=0;i<16;i++){const theta=i/16*Math.PI*2-Math.PI/2,ev=notes.filter(n=>Math.floor(n.step)===i),isAnchor=ev.some(anchor);ctx.strokeStyle=ev.length?isAnchor?color:'#9ba98a':'#b9c0ae';ctx.lineWidth=ev.length?isAnchor?3.8:2:1.2;ctx.beginPath();ctx.moveTo(x+Math.cos(theta)*75,y+Math.sin(theta)*75);ctx.lineTo(x+Math.cos(theta)*(ev.length?88:82),y+Math.sin(theta)*(ev.length?88:82));ctx.stroke();if(active&&i===step){ctx.fillStyle=color;ctx.beginPath();ctx.arc(x+Math.cos(theta)*79,y+Math.sin(theta)*79,5.5,0,Math.PI*2);ctx.fill();}}
  ctx.fillStyle='#363b30';ctx.beginPath();ctx.arc(x,y,25+energy*4,0,Math.PI*2);ctx.fill();ctx.fillStyle=color;ctx.beginPath();ctx.arc(x,y,6+energy*2,0,Math.PI*2);ctx.fill();if(energy){ctx.strokeStyle=color;ctx.globalAlpha=energy*.4;ctx.beginPath();ctx.arc(x,y,28+(1-energy)*45,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;}
 }else if(role==='voice'){
  const event=active?notes.filter(n=>n.step<=now).at(-1):notes.find(anchor),note=event?.note||65,frequency=(note-50)/18;
  for(let row=0;row<7;row++){ctx.beginPath();for(let x=10;x<=290;x+=2){const u=(x-10)/280,y=41+row*11+Math.sin(u*Math.PI*(3+frequency)+row*.22)*Math.sin(u*Math.PI)**1.6*(25+energy*9)*[.58,.84,1,.9,.76,.5,.36][row];if(x===10)ctx.moveTo(x,y);else ctx.lineTo(x,y);}ctx.strokeStyle=row===2||row===3?color:row<2?'#a8b7bc':'#bec6bd';ctx.lineWidth=row===2?2:1.1;ctx.stroke();}
  for(const n of notes){const x=10+n.step/15*280,y=168-((n.note-48)%24)*1.25;ctx.strokeStyle=anchor(n)?'#a7b3b3':'#d1d8ca';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,187);ctx.stroke();ctx.fillStyle=color;ctx.globalAlpha=anchor(n)?1:.43;ctx.beginPath();ctx.arc(x,y,active&&Math.floor(n.step)===step?4.3:anchor(n)?3:2,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;}
 }else if(role==='dust'){
  for(let i=0;i<135;i++){const u=random(i+1),v=random(i+54),x=10+u*280,y=89+Math.sin(u*7)*13+(v-.5)*(35*Math.sin(u*Math.PI)+10)*2,col=Math.floor(u*16),ev=notes.find(n=>Math.floor(n.step)===col),hot=active&&col===step;ctx.fillStyle=ev?color:'#bbc4a8';ctx.globalAlpha=hot?1:ev?.65:.35+v*.2;ctx.beginPath();ctx.arc(x,y,(ev?1.8:1)+(hot?1.2:0)+random(i+8)*.6,0,Math.PI*2);ctx.fill();}ctx.globalAlpha=1;
  for(const n of notes){const x=10+n.step/15*280;ctx.strokeStyle=color;ctx.globalAlpha=anchor(n)?.65:.28;ctx.lineWidth=anchor(n)?2:1;ctx.beginPath();ctx.moveTo(x,173);ctx.lineTo(Math.min(293,x+n.dur/root.RoleAccompaniment.STEP*17),173);ctx.stroke();}ctx.globalAlpha=1;
 }else{
  const current=active?notes.filter(n=>n.step<=now&&n.step+n.dur/root.RoleAccompaniment.STEP>now).at(-1):notes[0],tones=current?.harmony||[50,57,65],held=active&&current;
  for(let row=0;row<3;row++){const center=49+row*29,arch=16+(tones[row]%12)*.5+(held?energy*2:0);ctx.beginPath();for(let x=15;x<=285;x+=2){const u=(x-15)/270,y=center-Math.sin(Math.PI*u)*arch+Math.sin(u*Math.PI*2+row*.3)*5;if(x===15)ctx.moveTo(x,y);else ctx.lineTo(x,y);}for(let x=285;x>=15;x-=2){const u=(x-15)/270,y=center+Math.sin(Math.PI*u)*10+Math.sin(u*Math.PI*2+row*.3)*5;ctx.lineTo(x,y);}ctx.closePath();ctx.fillStyle=color;ctx.globalAlpha=held?.1:.06;ctx.fill();ctx.globalAlpha=1;ctx.strokeStyle=row===1?color:'#b7a587';ctx.lineWidth=held?1.8:1.2;ctx.stroke();}
  for(const n of notes){const x=10+n.step/16*280,len=Math.max(3,n.dur/root.RoleAccompaniment.STEP/16*280);ctx.strokeStyle=color;ctx.globalAlpha=anchor(n)?.85:.43;ctx.lineWidth=anchor(n)?2:1.5;for(let j=0;j<(n.notes?.length||1);j++){ctx.beginPath();ctx.moveTo(x,155+j*6);ctx.lineTo(Math.min(294,x+len),155+j*6);ctx.stroke();}}ctx.globalAlpha=1;
 }
 ctx.restore();
}
root.RoleArt={draw};
})(window);


