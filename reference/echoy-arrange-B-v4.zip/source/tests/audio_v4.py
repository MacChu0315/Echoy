from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1];E=R/'evidence';rows=[]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);p=b.new_page(viewport={'width':1450,'height':1100});p.set_content((R/'index.html').read_text())
 rows=p.evaluate('''async()=>{const rows=[],seed=PulseLab.clean([4,7,12].map(step=>({step,kind:'kick',vel:.74})));for(const role of Object.keys(RoleAccompaniment.ROLES))for(let phrase=1;phrase<=3;phrase++){
 const model=new ArrangeModel();model.setSeed('A',seed);model.configure('A',{role,phrase});const plan=model.compile().plans.A,data=await arrange.audio.preparePlan(plan),full=data.arrays.full;let prefix=0,peak=0,energy=0;for(let i=0;i<full.length;i++){if(i<4*.15625*24000)prefix=Math.max(prefix,Math.abs(full[i]));peak=Math.max(peak,Math.abs(full[i]));energy+=full[i]**2;}
 rows.push({test:role+'/'+phrase+' actual audio retains first-beat silence and has bounded output',passed:prefix<1e-7&&peak<=.65001&&energy>0,prefixPeak:prefix,peak,rms:Math.sqrt(energy/full.length)});
 }return rows;}''')
 p.evaluate('''window.probes=[];window.attachMeter=()=>{const a=arrange.audio.ctx.createAnalyser();a.fftSize=1024;arrange.audio.master.connect(a);window.meter=a;window.scan=setInterval(()=>{const x=new Float32Array(1024);a.getFloatTimeDomainData(x);probes.push(Math.max(...x.map(Math.abs)));},5);};void 0''')
 p.locator('[data-screen=A] [data-act=record]:enabled').click();p.wait_for_function('arrange.ui.A.state==="countin"');p.evaluate('attachMeter()');p.wait_for_timeout(750)
 has=p.evaluate('probes.some(n=>n>.00001)');rows.append({'test':'quiet count-in cues actually produce a signal','passed':has})
 p.locator('[data-screen=A] [data-act=record]:enabled').click();p.wait_for_timeout(250);p.evaluate('probes=[]');p.wait_for_timeout(1300)
 state=p.evaluate('({max:Math.max(...probes),state:arrange.ui.A.state,seed:arrange.tile("A").ownSeed.length})');rows.append({'test':'cancel removes future cue sounds without writing notes','passed':state['max']<1e-6 and state['state']=='ready' and state['seed']==0,'detail':state})
 p.evaluate('clearInterval(scan)');b.close()
(E/'audio-new.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));print(sum(x['passed'] for x in rows),'/',len(rows),'passed');assert all(x['passed'] for x in rows)
