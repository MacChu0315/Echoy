from pathlib import Path
from playwright.sync_api import sync_playwright
import json,sys
R=Path(__file__).resolve().parents[1];O=R/'evidence/layout';O.mkdir(parents=True,exist_ok=True);rows=[];errors=[]
def ck(name,ok,detail=None):
 rows.append(dict(test=name,passed=bool(ok),detail=detail));print(('PASS ' if ok else 'FAIL ')+name,flush=True);assert ok,(name,detail)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);p=b.new_page(viewport={'width':1480,'height':1180});p.set_default_timeout(7000);p.on('pageerror',lambda e:errors.append(str(e)))
 def sc():return p.locator('[data-screen=A]')
 def press(act):sc().locator(f'[data-act="{act}"]:enabled').click()
 def settle():p.wait_for_function('!arrange.model.pending&&!arrange.compiling.size')
 def geo():return sc().evaluate('''e=>{const s=e.getBoundingClientRect(),b=n=>{const r=n.getBoundingClientRect();return{x:r.x-s.x,y:r.y-s.y,w:r.width,h:r.height,right:r.right-s.x,bottom:r.bottom-s.y,cx:r.x+r.width/2-s.x,cy:r.y+r.height/2-s.y}};return{screen:[s.width,s.height],pad:b(e.querySelector('.pad')),steps:b(e.querySelector('.steps')),identity:b(e.querySelector('.identity')),battery:b(e.querySelector('.battery')),labels:[...e.querySelectorAll('.identity-role,.identity small')].map(n=>({...b(n),overflow:n.scrollWidth>n.clientWidth+1})),controls:[...e.querySelectorAll('.actions button:enabled')].map(n=>({...b(n),name:n.textContent})),mode:e.querySelector('.merge-strip').dataset.mode,background:getComputedStyle(e).backgroundColor,rails:[...e.querySelectorAll('.side')].map(n=>({base:b(n),rail:b(n.querySelector('.rail')),thumb:b(n.querySelector('.thumb'))}))}}''')
 def fit(label):
  g=geo();ck(label+' native geometry, aligned300px art and steps',g['screen']==[480,480] and g['pad']['w']==g['steps']['w']==300 and g['pad']['x']==g['steps']['x']==90 and g['pad']['y']==89,g)
  ck(label+' header fits one line, away from read-only battery',all(not n['overflow'] for n in g['labels']) and abs(g['labels'][0]['cy']-g['labels'][1]['cy'])<1 and g['labels'][-1]['right']+12<g['battery']['x'],g['labels'])
  ck(label+' active controls>=84px and inside screen',all(n['w']>=84 and n['h']>=84 and n['x']>=0 and n['right']<=480 and n['bottom']<=480 for n in g['controls']),g['controls'])
  ck(label+' slider tracks/handles remain centred',all(abs(n['base']['cx']-n['rail']['cx'])<.1 and abs(n['base']['cx']-n['thumb']['cx'])<.1 and n['base']['w']==64 for n in g['rails']))
 try:
  p.set_content((R/'index.html').read_text());p.wait_for_function('!!arrange');p.evaluate('arrange.model.setSeed("A",PulseLab.clean([0,2,10].map(step=>({step,kind:"kick",vel:.74}))));arrange.refresh()');settle()
  for lang in ['zh-CN','en']:
   p.locator(f'.language-outer [data-lang="{lang}"]').click()
   for role in ['pulse','voice','dust','harmony']:
    for phrase in [1,2,3]:
     p.evaluate('([role,phrase])=>{arrange.change("A",{role,phrase});}',[role,phrase]);settle();fit(f'{lang}/{role}/{phrase}')
     ck(f'{lang}/{role}/{phrase}: idle two enabled actions',sc().locator('.merge-strip button:enabled').count()==2)
    # All four role graphics remain their actual drawings while count-in proceeds.
    press('record');p.wait_for_function('arrange.ui.A.state==="countin"');p.wait_for_timeout(260)
    ck(f'{lang}/{role}: single Cancel with visible count-in',sc().locator('.merge-strip button:enabled').count()==1 and sc().locator('.merge-strip').get_attribute('data-mode')=='cancel' and sc().locator('[data-slot=state]').inner_text()!='')
    sc().screenshot(path=str(O/f'{lang}-{role}-countin.png'));press('record');p.wait_for_function('arrange.ui.A.state==="ready"')
    press('play');p.wait_for_function('arrange.tile("A").loop');p.wait_for_timeout(270)
    ck(f'{lang}/{role}: one Pause and no active recording key',sc().locator('.merge-strip button:enabled').count()==1 and sc().locator('[data-slot=record-entry]').is_disabled() and sc().locator('.merge-strip').get_attribute('data-mode')=='pause')
    sc().screenshot(path=str(O/f'{lang}-{role}-play.png'));press('play')
  # Screens do not become tall mobile mockups or scale down in a narrow window.
  p.set_viewport_size({'width':560,'height':1000});ck('narrow browser scrolls the desk, retains480 square',sc().evaluate('e=>e.getBoundingClientRect().width===480&&e.getBoundingClientRect().height===480'))
  p.set_viewport_size({'width':1480,'height':1180});p.emulate_media(reduced_motion='no-preference')
  # Inspect the real CSS interpolation after a normal press, not a video mockup.
  p.evaluate('window.tint=document.querySelector("[data-screen=A] .record-tint");window.strip=document.querySelector("[data-screen=A] .merge-strip");window.initialWidth=tint.getBoundingClientRect().width;document.querySelector("[data-screen=A] .merge-record").click()')
  p.wait_for_timeout(95);half=p.evaluate('({before:initialWidth,now:tint.getBoundingClientRect().width,total:strip.clientWidth})')
  ck('morph has a real intermediate width',half['before']<half['now']<half['total'],half)
  # Stop before the visual expansion completes: cancellation must not be delayed.
  p.evaluate('document.querySelector("[data-screen=A] .merge-single").click()')
  ck('Cancel works during transition, with no queued recorder',p.evaluate('arrange.ui.A.state==="ready"'))
  p.wait_for_timeout(300)
  ck('interrupted transition returns to a50/50 idle strip',sc().locator('.record-tint').evaluate('e=>Math.abs(e.offsetWidth-e.parentElement.clientWidth/2)<1'))
  # Failure, offline and recovery still use the existing simulator interfaces.
  p.evaluate('arrange.fail("A",new Error("test audio failure"))');ck('failure replaces whole screen with original recovery page',sc().locator('[data-route=status]').count()==1)
  sc().locator('[data-act=recover]').click();ck('recover stays silent and returns to merged idle',not p.evaluate('arrange.tile("A").loop') and sc().locator('.merge-strip').get_attribute('data-mode')=='idle')
  ck('no JS errors',not errors,errors)
 finally:
  (O/'checks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));(O/'errors.json').write_text(json.dumps(errors));p.screenshot(path=str(O/'last.png'));b.close()
print('PASS',len(rows))
