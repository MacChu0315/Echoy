from pathlib import Path
from playwright.sync_api import sync_playwright
import json,sys
R=Path(__file__).resolve().parents[1];E=R/'evidence/browser';E.mkdir(exist_ok=True,parents=True);rows=[];errors=[];requests=[]
def ck(name,ok,detail=None):
 rows.append({'name':name,'passed':bool(ok),'detail':detail});print(('PASS ' if ok else 'FAIL ')+name,flush=True);assert ok,(name,detail)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);p=b.new_page(viewport={'width':1780,'height':1180},device_scale_factor=1,accept_downloads=True);p.set_default_timeout(8000);p.on('pageerror',lambda e:errors.append(str(e)));p.on('request',lambda e:requests.append(e.url))
 def sc(id='A'):return p.locator(f'[data-screen="{id}"]')
 def click(id,act,val=None):sc(id).locator(f'[data-act="{act}"]:enabled'+(f'[data-phrase="{val}"]' if val is not None else '')).click()
 def waitsettle():p.wait_for_function('!arrange.model.pending && arrange.compiling.size===0 && !arrange.contactTimer',timeout=10000)
 def move(id,x,y,shelf=False):
  viewport=p.locator('#viewport');viewport.evaluate('e=>{e.scrollTop=0;e.scrollLeft=0}')
  el=p.locator(f'[data-shelf="{id}"]') if shelf else p.locator(f'[data-tile="{id}"] .device-handle')
  box=el.bounding_box();stage=p.locator('#stage').bounding_box();ox=254 if shelf else 170;oy=20
  startx=box['x']+min(box['width']-8,ox);starty=box['y']+20
  # Shelf drag centres the 508px device under the pointer by design.
  endx=stage['x']+x+(254 if shelf else min(box['width']-8,ox));endy=stage['y']+y+oy
  p.mouse.move(startx,starty);p.mouse.down();p.mouse.move(endx,endy,steps=18);p.mouse.up()
 try:
  p.set_content((R/'index.html').read_text());p.wait_for_timeout(180)
  ck('one tile starts ready, two in shelf, no autoplay',p.evaluate('Object.values(arrange.model.tiles).filter(d=>d.present).length===1&&!arrange.audio.ctx'))
  geom=sc().evaluate('e=>{const r=e.getBoundingClientRect();return{w:r.width,h:r.height,r:getComputedStyle(e).borderRadius,shell:e.parentElement.offsetWidth}}')
  ck('480×480 inner display, R60, independent508 casing',geom=={'w':480,'h':480,'r':'60px','shell':508},geom)
  ck('16 actual onset cells, 300px art, centered64px sliders',sc().evaluate('e=>e.querySelectorAll("[data-step]").length===16&&e.querySelector(".pad").offsetWidth===300&&[...e.querySelectorAll(".side")].every(s=>{const a=s.getBoundingClientRect(),r=s.querySelector(".rail").getBoundingClientRect();return a.width===64&&Math.abs((a.x+a.width/2)-(r.x+r.width/2))<.1})'))
  # Capture genuine taps, not an example substituted for the gesture.
  box=sc().locator('.pad').bounding_box();x=box['x']+120;y=box['y']+110
  sc().locator('[data-act=record]:enabled').click();p.wait_for_function('arrange.ui.A.state==="recording"');p.wait_for_timeout(170);p.mouse.click(x,y);p.wait_for_timeout(260);p.mouse.click(x+75,y);p.wait_for_timeout(620);p.mouse.click(x-50,y)
  p.wait_for_function('!!arrange.ui.A.preview',timeout=10000)
  ck('real input produces three retained onsets and one finite reply',p.evaluate('arrange.model.tiles.A.ownSeed.length===3&&!arrange.model.tiles.A.loop'))
  p.wait_for_function('!arrange.ui.A.preview',timeout=7000);starts=p.evaluate('arrange.audio.audit.filter(x=>x.type==="once-start").length');p.wait_for_timeout(600)
  ck('preview ends without enabling a loop or a second reply',p.evaluate('!arrange.model.tiles.A.loop&&arrange.audio.audit.filter(x=>x.type==="once-start").length')==starts)
  # Inspect all twelve options using the real per-tile gallery.
  click('A','role')
  for role in ['pulse','voice','dust','harmony']:
   while p.evaluate('arrange.model.tiles.A.role')!=role:click('A','next-role');waitsettle()
   for phrase in [1,2,3]:
    sc().locator(f'[data-phrase="{phrase}"]').click();waitsettle()
    ck(role+'/'+str(phrase)+' selected silently and source retained',p.evaluate('([r,n])=>arrange.model.tiles.A.current.role===r&&arrange.model.tiles.A.current.phrase===n&&!arrange.model.tiles.A.loop&&arrange.model.tiles.A.ownSeed.length===3',[role,phrase]))
  while p.evaluate('arrange.model.tiles.A.role')!='pulse':click('A','next-role');waitsettle()
  sc().locator('[data-phrase="1"]').click();waitsettle();click('A','back')
  click('A','play');p.wait_for_function('arrange.model.tiles.A.loop')
  p.evaluate('window.leftAudio=arrange.audio.mix.A.current;window.leftPlan=JSON.stringify(arrange.model.tiles.A.current);')
  move('B',548,22,True);p.wait_for_function('arrange.model.tiles.B.current?.source==="A"',timeout=10000);waitsettle()
  ck('physical shelf drag establishes A→B without starting B',p.evaluate('arrange.model.edges.length===1&&!arrange.model.tiles.B.loop&&arrange.model.tiles.A.loop'))
  ck('attachment keeps left audio source and phrase unchanged',p.evaluate('leftAudio===arrange.audio.mix.A.current&&leftPlan===JSON.stringify(arrange.model.tiles.A.current)'))
  ck('each confirmed seam appears at corresponding screen edge',sc().locator('.seam-mark.right.connected').count()==1 and sc('B').locator('.seam-mark.left.connected').count()==1)
  click('B','play');p.wait_for_function('arrange.model.tiles.B.loop');p.wait_for_function('arrange.now()>arrange.ui.B.loopAt')
  ck('B joins on the existing clock without restarting A',p.evaluate('arrange.model.tiles.B.clockId===arrange.model.tiles.A.clockId&&leftAudio===arrange.audio.mix.A.current&&Math.abs((arrange.ui.B.loopAt-arrange.model.clocks[arrange.model.tiles.A.clockId].origin)/2.5-Math.round((arrange.ui.B.loopAt-arrange.model.clocks[arrange.model.tiles.A.clockId].origin)/2.5))<1e-6'))
  p.evaluate('window.midAudio=arrange.audio.mix.B.current;window.upstream=JSON.stringify([arrange.model.tiles.A.current,arrange.model.tiles.B.current]);')
  move('C',1064,22,True);p.wait_for_function('arrange.model.tiles.C.current?.source==="B"',timeout=10000);waitsettle()
  ck('third tile has its own complete voice without rewriting A or B',p.evaluate('JSON.stringify([arrange.model.tiles.A.current,arrange.model.tiles.B.current])===upstream&&arrange.audio.mix.B.current===midAudio&&arrange.model.tiles.C.current.full.length>=arrange.model.tiles.C.current.foreground.length+3&&!arrange.model.tiles.C.loop'))
  click('C','play');p.wait_for_function('arrange.model.tiles.C.loop');p.wait_for_function('arrange.now()>arrange.ui.C.loopAt')
  # Make the testing source audible rather than only trusting transport flags.
  p.evaluate('window.meter=arrange.audio.ctx.createAnalyser();meter.fftSize=2048;arrange.audio.master.connect(meter)')
  p.wait_for_function('(()=>{const x=new Float32Array(meter.fftSize);meter.getFloatTimeDomainData(x);return x.some(v=>Math.abs(v)>.005)})()',timeout=5000)
  ck('real three-tile audio signal is present',True)
  signature=p.evaluate('JSON.stringify(Object.values(arrange.model.tiles).map(x=>x.current.signature))');p.wait_for_timeout(5200)
  ck('steady loops do not autonomously change content',signature==p.evaluate('JSON.stringify(Object.values(arrange.model.tiles).map(x=>x.current.signature))'))
  click('A','play');ck('muting A does not stop B/C or remove their input',p.evaluate('!arrange.model.tiles.A.loop&&arrange.model.tiles.B.loop&&arrange.model.tiles.C.loop&&arrange.model.tiles.B.current.source==="A"'))
  # B expression edit changes B+C at a safe boundary, never A.
  p.evaluate('window.beforeA=JSON.stringify(arrange.model.tiles.A.current);window.beforeC=arrange.model.tiles.C.current.signature;')
  click('B','role');sc('B').locator('[data-phrase="1"]').click();p.wait_for_function('!!arrange.model.pending');
  ck('new expression acknowledges before actual audio commit',p.evaluate('arrange.model.tiles.B.phrase===1&&arrange.model.tiles.B.current.phrase===2'))
  sc('B').locator('[data-phrase="3"]').click();waitsettle()
  ck('latest B intent commits downstream only',p.evaluate('arrange.model.tiles.B.current.phrase===3&&JSON.stringify(arrange.model.tiles.A.current)===beforeA&&arrange.model.tiles.C.current.signature!==beforeC'))
  click('B','back')
  # Relative volume control only changes its own output; zero really mutes.
  before=p.evaluate('({density:arrange.model.tiles.B.density,pos:JSON.stringify(arrange.positions),a:arrange.ui.A.volume,c:arrange.ui.C.volume})')
  sl=sc('B').locator('[data-control="volume"]');sl.focus();p.keyboard.press('ArrowDown')
  after=p.evaluate('({density:arrange.model.tiles.B.density,pos:JSON.stringify(arrange.positions),a:arrange.ui.A.volume,c:arrange.ui.C.volume})');ck('volume remains isolated from music, peers and geometry',before==after)
  # Actual top-case movements: make room, move B left, put A between B/C.
  move('A',32,590);waitsettle();move('B',32,22);waitsettle();move('A',548,22);waitsettle()
  ck('physical reversal makes B lead A and A lead C',p.evaluate('arrange.model.tiles.B.current.source===null&&arrange.model.tiles.A.current.source==="B"&&arrange.model.tiles.C.current.source==="A"'))
  # Split A/C while playing; no forced mute, no clearing.
  oldC=p.evaluate('JSON.stringify(arrange.model.tiles.C.current.full)');move('C',1130,78);waitsettle()
  ck('splitting keeps C sounding with same committed content and shared beat',p.evaluate('arrange.model.tiles.C.loop&&arrange.model.tiles.C.current.source===null') and oldC==p.evaluate('JSON.stringify(arrange.model.tiles.C.current.full)'))
  # Existing gallery/settings retain bilingual UI, not a new dashboard.
  for lang in ['en','zh-CN']:
   p.locator(f'.language-outer [data-lang="{lang}"]').click();click('B','role');sc('B').screenshot(path=str(E/f'{lang}-role.png'));ck(lang+' gallery retains three expression options',sc('B').locator('[data-phrase]').count()==3);click('B','back');click('B','settings');ck(lang+' full settings route',sc('B').locator('[data-route="settings"]').count()==1);click('B','info');ck(lang+' meaningful device details',len(sc('B').locator('.detail').inner_text())>70);click('B','back');click('B','back')
  p.locator('#lab summary').click();p.locator('#sim-target').select_option('B');p.locator('#sim-fault').click()
  ck('output fault stops only B and preserves its phrase',p.evaluate('!arrange.model.tiles.B.loop&&arrange.model.tiles.C.loop&&!!arrange.model.tiles.B.current') and sc('B').locator('[data-route="status"]').count()==1)
  p.locator('#sim-recover').click();ck('recovery does not auto-start B',p.evaluate('!arrange.model.tiles.B.loop&&!arrange.ui.B.fault'))
  p.locator('#sim-network').select_option('offline');waitsettle();ck('peer link loss retains local audio and committed phrase',p.evaluate('arrange.model.edges.length===0&&arrange.model.tiles.C.loop&&!!arrange.model.tiles.C.current'))
  with p.expect_download() as info:p.locator('#export-all').click()
  export=json.loads(Path(info.value.path()).read_text());ck('actual local export contains structured plans',export['simulated'] is True and len(export['tiles'])==3 and 'full' in export['tiles']['C']['current'])
  p.keyboard.press('Escape');p.wait_for_timeout(500)
  ck('Esc cancels all sources and no audio remains',p.evaluate('!Object.values(arrange.model.tiles).some(x=>x.loop)&&(()=>{const x=new Float32Array(meter.fftSize);meter.getFloatTimeDomainData(x);return x.every(v=>Math.abs(v)<1e-5)})()'))
  for id in ['A','B','C']:p.locator('#sim-target').select_option(id);p.locator('#sim-remove').click()
  waitsettle();ck('empty desk and all three shelf tiles are available',p.locator('#empty-desk').is_visible() and p.locator('.shelf-tile:visible').count()==3)
  ck('no runtime JS errors',not errors,errors);ck('no remote assets or services',not requests,requests)
 finally:
  (E/'checks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));(E/'errors.json').write_text(json.dumps(errors));p.screenshot(path=str(E/'last.png'),full_page=True);b.close()
print('TOTAL',len(rows),'passed')
