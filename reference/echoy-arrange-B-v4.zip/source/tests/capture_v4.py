from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw,ImageFont
import json
R=Path(__file__).resolve().parents[1];O=R/'evidence/capture';O.mkdir(parents=True,exist_ok=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=b.new_page(viewport={'width':1540,'height':1200},device_scale_factor=1);p.set_default_timeout(7000)
 p.set_content((R/'index.html').read_text());p.wait_for_function('!!arrange')
 def press(act):p.locator(f'[data-screen=A] [data-act="{act}"]:enabled').click()
 def shot(name):
  p.mouse.move(0,0);p.locator('[data-screen=A]').scroll_into_view_if_needed()
  p.locator('[data-tile=A]').evaluate('e=>{e.style.transform="none";const r=e.querySelector(".shell").getBoundingClientRect();e.style.transform=`translate(${Math.round(r.x)-r.x}px,${Math.round(r.y)-r.y}px)`;}')
  box=p.locator('[data-tile=A] .shell').bounding_box()
  p.screenshot(path=str(O/(name+'.png')),clip={'x':box['x'],'y':box['y'],'width':508,'height':508})
 p.evaluate('arrange.model.configure("A",{role:"voice",phrase:1});arrange.refresh()')
 p.wait_for_function('!arrange.compiling.size&&!arrange.model.pending')
 p.locator('#sample').click();p.wait_for_function('!!arrange.ui.A.preview');p.wait_for_function('!arrange.ui.A.preview',timeout=5500);p.wait_for_timeout(280)
 shot('idle')
 press('record');p.wait_for_function('arrange.ui.A.state==="countin"');p.wait_for_timeout(300);shot('countin')
 p.wait_for_function('arrange.ui.A.state==="recording"');p.wait_for_function('arrange.now()-arrange.ui.A.captureAt>.65')
 p.locator('[data-screen=A] .pad').click();p.wait_for_timeout(180);p.locator('[data-screen=A] .pad').click();p.wait_for_timeout(150);shot('recording')
 p.wait_for_function('!!arrange.ui.A.preview',timeout=7000);p.wait_for_function('!arrange.ui.A.preview',timeout=5500)
 press('play');p.wait_for_function('arrange.tile("A").loop&&arrange.now()>arrange.ui.A.loopAt+.25');p.wait_for_timeout(280);shot('playing')
 # Single-tile workflow is still part of the same real three-tile simulation.
 p.evaluate('arrange.add("B",{x:548,y:22})');p.wait_for_function('arrange.tile("B").current?.source==="A"',timeout=7000)
 p.locator('[data-screen=B] .merge-play:enabled').click();p.wait_for_function('arrange.tile("B").loop')
 p.evaluate('arrange.add("C",{x:1064,y:22})');p.wait_for_function('arrange.tile("C").current?.source==="B"',timeout=7000)
 p.locator('[data-screen=C] .merge-play:enabled').click();p.wait_for_function('arrange.tile("C").loop')
 p.mouse.move(0,0);p.evaluate('window.scrollTo(0,0)');p.screenshot(path=str(O/'three-tiles.png'),full_page=True)
 # Test ordinary file opening separately; do not change security policies.
 q=b.new_page();direct={}
 try:
  q.goto((R.parent/'echoy-arrange-B-v4.html').as_uri(),timeout=7000);q.wait_for_function('!!arrange',timeout=5000);direct={'passed':True,'title':q.title()}
 except Exception as e:direct={'passed':False,'reason':str(e)}
 (O/'direct-file.json').write_text(json.dumps(direct,ensure_ascii=False,indent=2));b.close()
font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
F=lambda size:ImageFont.truetype(font,size)
image=Image.new('RGB',(1604,670),'#f6f5ef');d=ImageDraw.Draw(image)
d.text((28,16),'合拍 / Echoy · 方案 A 已接入 v3',font=F(26),fill='#37442d')
d.text((28,56),'同一 HTML 的实际运行画面 · 480 × 480 内屏 · 声线 / 短句',font=F(15),fill='#7b866d')
for i,(name,label) in enumerate([('idle','空闲 · 录制 / 播放'),('recording','录入 · 整条取消'),('playing','演奏 · 整条暂停')]):
 x=28+i*520;im=Image.open(O/(name+'.png')).convert('RGB');assert im.size==(508,508)
 image.paste(im,(x,108));d.text((x+14,632),label,font=F(18),fill='#586a49')
image.save(R.parent/'echoy-arrange-B-v4-preview.png')
print('Captured actual idle, count-in, recording, playback and three-tile views.')
print('Direct file navigation:',direct)
