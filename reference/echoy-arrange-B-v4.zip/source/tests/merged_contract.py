"""Run against the exact HTML; verify the approved merged-strip contract."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import sys,json
R=Path(__file__).resolve().parents[1]
f=Path(sys.argv[1]);label=sys.argv[2];O=R/'evidence'/label;O.mkdir(parents=True,exist_ok=True)
rows=[];errors=[]
def ck(name,ok,detail=None):
 rows.append(dict(test=name,passed=bool(ok),detail=detail));print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 assert ok,(name,detail)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 p=b.new_page(viewport={'width':1550,'height':1200});p.set_default_timeout(5500);p.on('pageerror',lambda e:errors.append(str(e)))
 try:
  p.set_content(f.read_text());p.wait_for_function('!!window.arrange');s=p.locator('[data-screen=A]')
  ck('one grouped strip replaces the top Record and lone Play',s.locator('.merge-strip').count()==1 and s.locator('.home-head [data-act=record]').count()==0)
  strip=s.locator('.merge-strip')
  def press(act):s.locator(f'[data-act="{act}"]:enabled').click()
  def strip_mode(mode):p.wait_for_function('(mode)=>document.querySelector("[data-screen=A] .merge-strip").dataset.mode===mode',arg=mode)
  def enabled_actions():return strip.locator('button:enabled').evaluate_all('els=>els.map(e=>e.dataset.act)')
  ck('empty state keeps Record enabled and Play disabled',enabled_actions()==['record'])
  ck('identity is one horizontal role-dot-phrase line',s.locator('.identity').evaluate('e=>{const a=e.querySelector(".identity-role").getBoundingClientRect(),b=e.querySelector("small").getBoundingClientRect();return Math.abs(a.y+a.height/2-b.y-b.height/2)<1&&e.textContent.includes("·")}'))
  ck('screen remains native480x480 and R60',s.evaluate('e=>{const r=e.getBoundingClientRect();return r.width===480&&r.height===480&&getComputedStyle(e).borderRadius==="60px"}'))
  # Initial audition must never arm recording.
  s.locator('.pad').click();p.wait_for_timeout(120)
  ck('ordinary pad touch stays a live audition only',p.evaluate('arrange.ui.A.state==="ready"&&arrange.ui.A.raw.length===0&&arrange.tile("A").ownSeed.length===0'))
  press('record');p.wait_for_function('arrange.ui.A.state==="countin"');strip_mode('cancel')
  ck('entire strip is a single enabled Cancel during count-in',enabled_actions()==['record'] and strip.locator('.merge-single:enabled').count()==1)
  ck('no independent top Cancel and no removed caption',s.locator('.home-head button').count()==0 and '提示音不会录入' not in s.inner_text())
  ck('two-beat prep is visible without rewriting the timer', '预备' in s.locator('[data-slot=state]').inner_text())
  # Both ends of the unified button can cancel, not only the old record half.
  r=strip.bounding_box();p.mouse.click(r['x']+r['width']-16,r['y']+42);p.wait_for_function('arrange.ui.A.state==="ready"');strip_mode('idle');p.wait_for_timeout(1500)
  ck('right end Cancel clears future count-in/capture',p.evaluate('arrange.ui.A.state==="ready"&&!arrange.ui.A.preview&&arrange.ui.A.raw.length===0'))
  press('record');p.wait_for_function('arrange.ui.A.state==="recording"');p.wait_for_function('arrange.now()-arrange.ui.A.captureAt>.64')
  s.locator('.pad').click();p.wait_for_timeout(630);s.locator('.pad').click()
  p.wait_for_function('!!arrange.ui.A.preview',timeout=7000);strip_mode('pause')
  ck('completed recording previews once with one full Pause',enabled_actions()==['play'] and strip.locator('.merge-single:enabled').count()==1 and not p.evaluate('arrange.tile("A").loop'))
  ck('leading rest remains in source and full reply',p.evaluate('arrange.tile("A").ownSeed.length===2&&arrange.tile("A").ownSeed[0].step>=4&&arrange.tile("A").current.full.every(n=>n.step>=4)'))
  p.wait_for_function('document.querySelector("[data-screen=A] [data-slot=state]").textContent.includes("一次")',timeout=1200)
  ck('finite preview is identified, not confused with repeat', '一次' in s.locator('[data-slot=state]').inner_text())
  p.wait_for_function('!arrange.ui.A.preview',timeout=5000);strip_mode('idle')
  ck('automatic reply completion returns to Record and Play',enabled_actions()==['record','play'] and not p.evaluate('arrange.tile("A").loop'))
  p.evaluate('window.oldSeed=JSON.stringify(arrange.tile("A").ownSeed)')
  press('play');p.wait_for_function('arrange.tile("A").loop');strip_mode('pause')
  ck('playing hides/disables Record; only Pause accepts input',enabled_actions()==['play'] and strip.locator('[data-slot=record-entry]').is_disabled())
  r=strip.bounding_box();p.mouse.click(r['x']+16,r['y']+42);p.wait_for_function('!arrange.tile("A").loop');strip_mode('idle')
  ck('left end Pause stops only this tile and retains phrase',p.evaluate('!arrange.tile("A").loop&&oldSeed===JSON.stringify(arrange.tile("A").ownSeed)'))
  press('record');p.wait_for_function('arrange.ui.A.state==="recording"');p.wait_for_function('arrange.ui.A.state==="ready"',timeout=5000);strip_mode('idle')
  ck('empty recording retains old rhythm and stays silent',p.evaluate('oldSeed===JSON.stringify(arrange.tile("A").ownSeed)&&!arrange.ui.A.preview&&!arrange.tile("A").loop'))
  # Cross keyboard paths without leaving focus on an inert control.
  rec=strip.locator('[data-slot=record-entry]');rec.focus();p.keyboard.press('Enter');p.wait_for_function('arrange.ui.A.state==="countin"')
  ck('focus follows the newly active Cancel',p.evaluate('document.activeElement.matches(".merge-single")'))
  p.keyboard.press('Enter');strip_mode('idle')
  ck('focus returns to the recording entry after cancel',p.evaluate('document.activeElement.matches(".merge-record")'))
  p.emulate_media(reduced_motion='reduce')
  ck('reduced-motion preference removes morph travel',strip.locator('.merge-tint.record-tint').evaluate('e=>getComputedStyle(e).transitionDuration.split(",").every(x=>parseFloat(x)===0)'))
  ck('no runtime script errors',not errors,errors)
 finally:
  (O/'checks.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2));(O/'errors.json').write_text(json.dumps(errors));p.screenshot(path=str(O/'last.png'));b.close()
print('PASS',len(rows))
