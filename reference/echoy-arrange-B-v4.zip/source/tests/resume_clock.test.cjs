const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.resolve(__dirname,'..'),w={console};w.window=w;w.globalThis=w;vm.createContext(w);for(const f of ['baseline/core.js','src/arrangement.js'])vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'),w);
test('pausing all devices does not reset the already established common beat on resume',()=>{
 const m=new w.ArrangeModel();m.setSeed('A',[{step:4,kind:'kick',vel:.74}]);const staged=m.stage(m.compile(),0);m.commit(staged.at+.01);
 m.enableLoop('A',1);const origin=m.clocks.A.origin;m.mute('A');const start=m.enableLoop('A',5.4);
 assert.equal(m.clocks.A.origin,origin);assert.ok(Math.abs((start-origin)/2.5-Math.round((start-origin)/2.5))<1e-8);
});
