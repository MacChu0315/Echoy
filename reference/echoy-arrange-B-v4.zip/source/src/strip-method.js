 /* Presentation adapter only: active controls reuse arm()/transport(). Mutually
    exclusive hit areas switch immediately; animation never delays cancellation. */
 updateStrip(id,screen,{capture,busy,pending,preparing}){
  const strip=screen.querySelector('.merge-strip');if(!strip)return;
  const d=this.tile(id),mode=capture?'cancel':busy?'pause':'idle',previous=strip.dataset.mode;
  const record=strip.querySelector('.merge-record'),play=strip.querySelector('.merge-play'),single=strip.querySelector('.merge-single');
  const focused=strip.contains(document.activeElement);
  strip.dataset.mode=mode;strip.setAttribute('aria-label',this.t('本机录制与播放','Record and play this tile'));
  if(strip.dataset.locale!==this.lang){
   record.innerHTML=ico('record')+`<span>${this.t('录制','Record')}</span>`;
   play.innerHTML=ico('play')+`<span>${this.t('播放','Play')}</span>`;
   strip.dataset.locale=this.lang;
  }
  record.disabled=mode!=='idle'||!this.canRecord(id)||preparing||pending;
  play.disabled=mode!=='idle'||!d.current||pending||preparing;
  for(const button of [record,play]){button.inert=mode!=='idle';button.setAttribute('aria-hidden',String(mode!=='idle'));button.tabIndex=mode==='idle'?0:-1;}
  record.setAttribute('aria-pressed','false');record.dataset.mode='record';play.dataset.mode='play';
  record.setAttribute('aria-label',this.t('录制：预备两拍，记录四拍','Record: two count-in beats, four recording beats'));
  record.title=!this.canRecord(id)?this.t('先拆开左侧，再录自己的节奏','Unlink left before recording'):'';
  play.setAttribute('aria-label',this.t('播放本机，稳定重复这段','Play this tile; repeat the current phrase'));
  single.disabled=mode==='idle';single.inert=mode==='idle';single.tabIndex=mode==='idle'?-1:0;
  single.setAttribute('aria-hidden',String(mode==='idle'));
  // Removing the inactive action also keeps delegated events unambiguous.
  single.dataset.act=mode==='cancel'?'record':mode==='pause'?'play':'inactive';
  if(single.dataset.mode!==mode||single.dataset.locale!==this.lang){
   single.innerHTML=(mode==='cancel'?ico('cross'):pauseIcon)+`<span>${this.t(mode==='cancel'?'取消':'暂停',mode==='cancel'?'Cancel':'Pause')}</span>`;
   single.dataset.mode=mode;single.dataset.locale=this.lang;
  }
  single.setAttribute('aria-label',this.t(mode==='cancel'?'取消录制，保留原节奏':'暂停本机',mode==='cancel'?'Cancel recording; keep original':'Pause this tile'));
  if(focused&&previous!==mode){
   const next=mode!=='idle'?single:previous==='cancel'?record:play;
   (next.disabled?record:next).focus({preventScroll:true});
  }
 }
