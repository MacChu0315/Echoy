from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
R=Path(__file__).resolve().parent;D=R.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# All evidence must correspond to the final emitted file.
expected={'evidence/final/checks.json':20,'evidence/layout/checks.json':143,'evidence/browser/checks.json':44,'evidence/audio-new.json':14}
for f,count in expected.items():
 rows=json.loads((R/f).read_text());assert len(rows)==count,(f,len(rows));assert all(x['passed'] for x in rows),f
log=(R/'evidence/model-final.txt').read_text();assert '# pass 13' in log and '# fail 0' in log
assert (D/'echoy-arrange-B-v3.html').read_bytes()==(R/'baseline/source-v3.html').read_bytes()
assert sha(D/'echoy-arrange-B-v3.html')=='241a0a58e0e33cb906b4bf637c2d55f219de988df2a683c68d68f767c7dee6b5'
assert (R/'index.html').read_bytes()==(D/'echoy-arrange-B-v4.html').read_bytes()
for f in ['src/app.js','src/inherited-view.js','src/arrangement.js','src/audio.js']:
 subprocess.run(['node','--check',str(R/f)],check=True)
preservation=json.loads((R/'evidence/preservation.json').read_text());assert all(x['unchanged'] for x in preservation['files'])
manifest={'source':'echoy-arrange-B-v3.html','source_sha256':sha(D/'echoy-arrange-B-v3.html'),'output':'echoy-arrange-B-v4.html','output_sha256':sha(D/'echoy-arrange-B-v4.html'),'baseline_v3_untouched':True,'approved_reference':'echoy-merged-strip-caption-removed.png','reference_sha256':sha(D/'echoy-merged-strip-caption-removed.png'),'models':13,'merged_controls':20,'layout':143,'multi_device':44,'audio':14,'hardware_tested':False,'direct_file':json.loads((R/'evidence/capture/direct-file.json').read_text())}
(R/'evidence/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
shutil.copy2(R/'verification.md',D/'echoy-arrange-B-v4-verification.md')
archive=D/'echoy-arrange-B-v4.zip'
tests={'merged_contract.py','layout_v4.py','multi_v4.py','audio_v4.py','model.test.cjs','resume_clock.test.cjs','capture_v4.py'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 z.write(D/'echoy-arrange-B-v4.html','echoy-arrange-B-v4.html');z.write(R/'README.md','README.md');z.write(R/'verification.md','verification.md');z.write(D/'echoy-arrange-B-v4-preview.png','preview.png')
 for f in [R/'apply_patch.py',R/'build.py',R/'package.py',R/'index.html']:z.write(f,'source/'+f.name)
 for folder in ['src','baseline']:
  for f in sorted((R/folder).glob('*')):
   if f.is_file() and f.suffix in {'.js','.css','.html','.json'}:z.write(f,'source/'+str(f.relative_to(R)))
 for name in sorted(tests):z.write(R/'tests'/name,'source/tests/'+name)
 for f in sorted((R/'evidence').rglob('*')):
  if f.is_file() and f.suffix in {'.json','.txt','.diff','.png'}:
   z.write(f,'source/'+str(f.relative_to(R)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert z.read('echoy-arrange-B-v4.html')==(D/'echoy-arrange-B-v4.html').read_bytes()
 assert not any(n.endswith(('.ttf','.otf','.ttc','.woff','.woff2')) for n in z.namelist())
print('FINAL VERIFIED:',manifest['output_sha256'])
print('13 model + 20 merged interaction + 143 layout/state + 44 multi-device + 14 real-audio checks passed.')
for name in ['echoy-arrange-B-v4.html','echoy-arrange-B-v4-preview.png','echoy-arrange-B-v4.zip','echoy-arrange-B-v4-verification.md']:
 p=D/name;assert p.is_file();print(name,p.stat().st_size)
