"""Apply the approved UI to the supplied v3, without replacing its music/runtime."""
from pathlib import Path
R=Path(__file__).resolve().parent
s=(R/'baseline/v3-inherited-view.js').read_text()
old='<div class="identity">${this.name()}<small>${this.phraseName()}</small></div>${this.batterySvg()}<button class="record-entry" data-act="record" id="record-entry" aria-pressed="false">${ico(\'record\')}<span>${this.t(\'录一段\',\'Record\')}</span></button>'
new='<div class="identity"><span class="identity-role">${this.name()}</span><span class="identity-separator" aria-hidden="true">·</span><small>${this.phraseName()}</small></div>${this.batterySvg()}'
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('<div class="hint" id="hint"></div>','')
old='<button class="transport" data-act="play" id="transport"></button>'
new='''<div class="merge-strip" data-mode="idle" role="group" aria-label="${this.t('本机录制与播放','Record and play this tile')}"><i class="merge-tint record-tint" aria-hidden="true"></i><i class="merge-tint play-tint" aria-hidden="true"></i><i class="merge-divider" aria-hidden="true"></i><button class="merge-record" data-act="record" id="record-entry">${ico('record')}<span>${this.t('录制','Record')}</span></button><button class="merge-play" data-act="play" id="transport">${ico('play')}<span>${this.t('播放','Play')}</span></button><button class="merge-single" id="strip-action" data-act="inactive" disabled inert aria-hidden="true" tabindex="-1"></button></div>'''
assert s.count(old)==1;s=s.replace(old,new)
(R/'src/inherited-view.js').write_text(s)
s=(R/'baseline/v3-app.js').read_text()
a=s.index(' update(id){');s=s[:a]+(R/'src/strip-method.js').read_text()+s[a:]
a=s.index('  let status,hint;');b=s.index("  screen.querySelector('.state-line')",a)
s=s[:a]+'''  let status='';
  if(capture){
   if(u.state==='unlocking')status=this.t('准备录制','Preparing to record');
   else if(u.state==='countin')status=this.t('预备 · ','Ready · ')+Math.max(1,Math.min(PREP_BEATS,Math.ceil((u.captureAt-this.now())/BEAT)));
   else status=this.t('录入 · ','Recording · ')+Math.max(1,Math.min(4,1+Math.floor((this.now()-u.captureAt)/BEAT)))+' / 4';
  }
  else if(preparing)status=this.t('准备新的声音','Preparing a new sound');
  else if(pending)status=this.t('下一小节生效','Changes at the next bar');
  else if(u.preview)status=this.now()<u.preview.start?this.t('等共同拍点试听','Audition at the shared beat'):this.t('试听一次 · 结束自动停','One reply · Stops at the end');
  else if(d.loop&&this.now()<u.loopAt)status=this.t('等共同拍点开始','Waiting for the shared beat');
  else if(!d.current)status=this.t('中央试奏 · 录制才保存','Tap to try · Record to keep');
  put('state',u.message||status);put('touch-label',!d.current&&!capture?this.t('试奏区','Try here'):'');
'''+s[b:]
a=s.index('  const record=screen.querySelector');b=s.index('  const gallery=',a)
s=s[:a]+"  this.updateStrip(id,screen,{capture,busy,pending,preparing});\n"+s[b:]
# Visible instructions follow the new label; guidance remains outside steady home.
s=s.replace('点首页「录一段」','点首页「录制」').replace('点「录一段」','点「录制」')
(R/'src/app.js').write_text(s)
